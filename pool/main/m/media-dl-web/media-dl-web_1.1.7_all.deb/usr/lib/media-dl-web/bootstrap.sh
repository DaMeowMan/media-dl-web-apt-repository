#!/bin/sh
# bootstrap.sh - build the media-dl-web app folder. Used by the .deb, the portable archive and the AppImage.
#
#   sh bootstrap.sh [--ffmpeg]
#
# Creates under $MEDIA_DL_WEB_APP (default /opt/media-dl-web):
#   venv/            Python venv (uv): gallery-dl, the add-ons yt-dlp can use (curl_cffi, brotli, ...)
#   bin/yt-dlp       the official yt-dlp release file (downloaded with wget/curl, checksum verified), so `yt-dlp -U` works
#                    (when run as root a copy is also placed in /usr/local/bin)
#   vendor/          hls.js (browser player library)
#   yt-dlp.conf      JavaScript runtime for YouTube (private to this app)
#   bin/ffmpeg ...   only with --ffmpeg and only when the system has none
# Env: MEDIA_DL_WEB_APP  MEDIA_DL_WEB_LIB (folder holding media_dl_web.py; default: next to this script)
#      MEDIA_DL_WEB_PYTHON  STATE_DIRECTORY (where config.json, with proxy settings, lives)  MEDIA_DL_WEB_PROXY
set -e

APP="${MEDIA_DL_WEB_APP:-/opt/media-dl-web}"
LIB="${MEDIA_DL_WEB_LIB:-$(cd "$(dirname "$0")" && pwd)}"
PYTHON="${MEDIA_DL_WEB_PYTHON:-$(command -v python3 || true)}"
VENV="$APP/venv"
WITH_FFMPEG=0
[ "${1:-}" = "--ffmpeg" ] && WITH_FFMPEG=1
say() { echo "==> $*"; }

[ -n "$PYTHON" ] || { echo "media-dl-web: python3 not found" >&2; exit 1; }
"$PYTHON" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' \
    || { echo "media-dl-web: Python 3.9 or newer is required" >&2; exit 1; }
"$PYTHON" -c 'import venv, ensurepip' 2>/dev/null \
    || { echo "media-dl-web: the python3 'venv' module is missing (Debian/Ubuntu: sudo apt install python3-venv python3-pip)" >&2; exit 1; }
mkdir -p "$APP"

if [ -n "${MEDIA_DL_WEB_PROXY:-}" ]; then
    export HTTP_PROXY="$MEDIA_DL_WEB_PROXY" HTTPS_PROXY="$MEDIA_DL_WEB_PROXY" ALL_PROXY="$MEDIA_DL_WEB_PROXY"
    export http_proxy="$MEDIA_DL_WEB_PROXY" https_proxy="$MEDIA_DL_WEB_PROXY" all_proxy="$MEDIA_DL_WEB_PROXY"
fi
export UV_PYTHON_DOWNLOADS=never UV_LINK_MODE=copy
export MEDIA_DL_WEB_APP="$APP" MEDIA_DL_WEB_VENV="$VENV"

# ---- uv: use the system one, or bootstrap a throw-away copy from PyPI ----------------------
UV="$(command -v uv || true)"; BOOT=""
if [ -z "$UV" ]; then
    say "uv not found, bootstrapping it from PyPI"
    BOOT="$APP/.uv-bootstrap"; rm -rf "$BOOT"
    "$PYTHON" -m venv "$BOOT"
    "$BOOT/bin/pip" install --quiet --disable-pip-version-check uv
    UV="$BOOT/bin/uv"
fi

# ---- venv -------------------------------------------------------------------------------------
say "creating the Python environment"
rm -rf "$VENV"
"$UV" venv --seed --python "$PYTHON" "$VENV"
pipi() {
    if [ ! -x "$UV" ] && [ -x "$VENV/bin/uv" ]; then UV="$VENV/bin/uv"; fi
    "$UV" pip install --python "$VENV/bin/python" "$@"
}
try_pip() { pipi "$@" || echo "media-dl-web: optional install failed: $*"; }
run_py()  { "$VENV/bin/python" "$LIB/media_dl_web.py" "$@"; }

pipi gallery-dl mutagen requests pyyaml websockets pysocks
pipi uv                                   # the Updates tab uses it
[ -z "$BOOT" ] || rm -rf "$BOOT"
# the bootstrap copy is gone; later installs must use the uv now inside the venv
if [ ! -x "$UV" ] && [ -x "$VENV/bin/uv" ]; then
    UV="$VENV/bin/uv"
fi

# ---- yt-dlp: the official release file + the Python add-ons it can use ---------------------------
say "installing yt-dlp (release file) and its add-ons"
fetch_file() {   # fetch_file URL DEST   (wget, else curl, else python)
    if command -v wget >/dev/null 2>&1; then wget -q "$1" -O "$2"
    elif command -v curl >/dev/null 2>&1; then curl -fsSL "$1" -o "$2"
    else "$PYTHON" -c 'import sys, urllib.request; urllib.request.urlretrieve(sys.argv[1], sys.argv[2])' "$1" "$2"
    fi
}
YT_BASE="https://github.com/yt-dlp/yt-dlp/releases/latest/download"
mkdir -p "$APP/bin"
fetch_file "$YT_BASE/yt-dlp" "$APP/bin/yt-dlp.new"
# The official Unix release is a zipapp: "#!/usr/bin/env python3" then the ZIP.
# A raw ZIP is accepted too. Requiring PK at byte 0 rejects every current build.
if ! "$PYTHON" -c '
import os, sys
path = sys.argv[1]
size = os.path.getsize(path)
with open(path, "rb") as f:
    head = f.read(262144)
pk = head.find(b"PK\x03\x04")
prefix_ok = pk == 0 or (
    0 < pk <= 256 and head[:pk].startswith(b"#!") and head[pk - 1:pk] == b"\n" and b"\x00" not in head[:pk])
if size >= 500_000 and prefix_ok and b"yt_dlp/" in head:
    sys.exit(0)
sys.stderr.write("media-dl-web: the downloaded file is not the yt-dlp release (size %s, starts with %r)\n" % (size, bytes(head[:24])))
sys.exit(1)
' "$APP/bin/yt-dlp.new"; then
    rm -f "$APP/bin/yt-dlp.new"
    exit 1
fi
if command -v sha256sum >/dev/null 2>&1 && fetch_file "$YT_BASE/SHA2-256SUMS" "$APP/bin/SHA2-256SUMS.tmp" 2>/dev/null; then
    want="$(awk '$2=="yt-dlp"{print $1}' "$APP/bin/SHA2-256SUMS.tmp")"
    got="$(sha256sum "$APP/bin/yt-dlp.new" | awk '{print $1}')"
    rm -f "$APP/bin/SHA2-256SUMS.tmp"
    if [ -n "$want" ] && [ "$want" != "$got" ]; then
        rm -f "$APP/bin/yt-dlp.new"
        echo "media-dl-web: yt-dlp checksum mismatch, refusing to install it" >&2; exit 1
    fi
    [ -n "$want" ] && echo "media-dl-web: yt-dlp checksum verified"
else
    rm -f "$APP/bin/SHA2-256SUMS.tmp"
    echo "media-dl-web: (could not verify the yt-dlp checksum)"
fi
chmod a+rx "$APP/bin/yt-dlp.new"
mv "$APP/bin/yt-dlp.new" "$APP/bin/yt-dlp"
# a system-wide copy, so `yt-dlp` also works in a terminal (only when installing as root)
if [ "$(id -u)" = 0 ] && [ -d /usr/local/bin ]; then
    cp -a "$APP/bin/yt-dlp" /usr/local/bin/yt-dlp
fi
# the Python add-ons yt-dlp can use (curl_cffi for impersonation, etc.): use the venv's own pip,
# then drop the pip copy of yt-dlp itself: the release file above is the real one
"$VENV/bin/python" -m pip install --disable-pip-version-check -q "yt-dlp[default,curl-cffi,secretstorage]" \
    || echo "media-dl-web: optional install failed: yt-dlp[default,curl-cffi,secretstorage]"
"$VENV/bin/python" -m pip uninstall -y --disable-pip-version-check yt-dlp >/dev/null 2>&1 || true
if ! "$VENV/bin/python" -c "import curl_cffi" 2>/dev/null; then
    echo "media-dl-web: curl_cffi (yt-dlp impersonation) failed to install on $(uname -m)" >&2
    exit 1
fi
try_pip xattr
for p in toml jinja2 truststore; do try_pip "$p"; done          # gallery-dl extras

# ---- JavaScript runtime for YouTube; written to a PRIVATE yt-dlp config used only by this app ------
say "looking for a JavaScript runtime"
[ -x "$VENV/bin/deno" ] || try_pip deno
if ! [ -x "$VENV/bin/deno" ] && ! [ -x "$VENV/bin/node" ]; then try_pip nodejs-wheel-binaries; fi
RUNTIME=""
if [ -x "$VENV/bin/deno" ]; then RUNTIME="deno:$VENV/bin/deno"
elif [ -x "$VENV/bin/node" ]; then RUNTIME="node:$VENV/bin/node"
elif command -v node >/dev/null 2>&1 \
     && [ "$(node -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)" -ge 22 ]; then
    RUNTIME="node:$(command -v node)"
fi
if [ -n "$RUNTIME" ]; then
    printf '# media-dl-web: generated\n--js-runtimes %s\n' "$RUNTIME" > "$APP/yt-dlp.conf"
else
    rm -f "$APP/yt-dlp.conf"
    echo "media-dl-web: no JS runtime (deno / node>=22) found; YouTube may fail until you install one"
fi

# ---- hls.js (browser-side player library) ----------------------------------------------------------
say "installing hls.js"
run_py update hls.js || echo "media-dl-web: could not fetch hls.js now; install it later from the Updates tab"

# ---- ffmpeg, only when asked for and only when the system has none ----------------------------------
if [ "$WITH_FFMPEG" = 1 ]; then
    say "checking for ffmpeg"
    run_py install-ffmpeg || echo "media-dl-web: could not get ffmpeg; install it with your package manager"
fi
say "app folder ready: $APP"
