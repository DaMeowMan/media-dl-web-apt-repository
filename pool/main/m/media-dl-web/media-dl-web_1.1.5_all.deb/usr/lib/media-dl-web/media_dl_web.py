#!/usr/bin/env python3
"""
media-dl-web - browser UI for yt-dlp (videos) and gallery-dl (images).

Same idea as the Tk app "media-dl", but served over HTTP:
  * download videos (yt-dlp) / images (gallery-dl), extractor picker, live log + status
  * play anything in the browser: files the browser can decode are served directly
    (HTTP range requests); everything else is transcoded on the fly by ffmpeg into
    HLS (H.264/AAC) and played with hls.js, so codec/container limits don't matter
  * fullscreen player, thumbnails, library of downloaded files

Standard library only; yt-dlp / gallery-dl / ffmpeg are external.
Re-launches itself inside the venv (default /opt/media-dl-web/venv) if present.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import importlib
import io
import importlib.metadata
import json
import mimetypes
import os
import re
import secrets
import shlex
import shutil
import socket
import socketserver
import ssl
import signal
import subprocess
import sys
import tempfile
import urllib.parse
import threading
import time
import urllib.request
import zipfile
from concurrent.futures import ThreadPoolExecutor
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

APP = Path(os.environ.get("MEDIA_DL_WEB_APP", "/opt/media-dl-web"))
VENV = Path(os.environ.get("MEDIA_DL_WEB_VENV", str(APP / "venv")))
VENV_BIN = VENV / "bin"
VERSION = "1.1.5"


def _reexec_in_venv() -> None:
    py = VENV_BIN / "python"
    if os.environ.get("MEDIA_DL_WEB_REEXEC") or not py.exists():
        return
    try:
        if Path(sys.prefix).resolve() == VENV.resolve():
            return
    except OSError:
        return
    os.environ["MEDIA_DL_WEB_REEXEC"] = "1"
    os.execv(str(py), [str(py), os.path.abspath(__file__), *sys.argv[1:]])


_reexec_in_venv()

HERE = Path(__file__).resolve().parent
STATIC_DIR = Path(os.environ.get("MEDIA_DL_WEB_STATIC", HERE / "static"))
VENDOR_DIR = APP / "vendor"                       # hls.min.js is fetched here at install time
YTDLP_CONF = APP / "yt-dlp.conf"                  # private yt-dlp config (js runtime); shared nowhere
BIN_DIR = APP / "bin"                             # the yt-dlp release file lives here, so `yt-dlp -U` can replace it
PLUGINS_DIR = APP / "yt-dlp-plugins"              # <name>/yt_dlp_plugins/{extractor,postprocessor}/*.py


def ytdlp_cmd() -> list[str] | None:
    """How to run yt-dlp: the release zipapp (self-updating) run by the venv python so it sees curl_cffi etc.;
    otherwise a pip-installed or system yt-dlp."""
    env = os.environ.get("MEDIA_DL_WEB_YTDLP")
    if env:
        return [env]
    b = BIN_DIR / "yt-dlp"
    if b.is_file():
        py = VENV_BIN / "python"
        return [str(py if py.exists() else sys.executable), str(b)]
    legacy = VENV_BIN / "yt-dlp"
    if legacy.exists():
        return [str(legacy)]
    w = shutil.which("yt-dlp")
    return [w] if w else None


def ytdlp_args() -> list[str]:
    """Options every yt-dlp run gets: our private config (JS runtime) and our plugin directory."""
    a: list[str] = []
    if YTDLP_CONF.exists():
        a += ["--ignore-config", "--config-locations", str(YTDLP_CONF)]
    try:
        if PLUGINS_DIR.is_dir() and any(p.is_dir() or p.suffix == ".zip" for p in PLUGINS_DIR.iterdir()):
            a += ["--plugin-dirs", str(PLUGINS_DIR)]
    except OSError:
        pass
    return a


GDL = str(VENV_BIN / "gallery-dl") if (VENV_BIN / "gallery-dl").exists() else (shutil.which("gallery-dl") or "gallery-dl")
FFMPEG = shutil.which("ffmpeg") or "ffmpeg"
FFPROBE = shutil.which("ffprobe") or "ffprobe"

IMG_EXT = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".avif"}
VID_EXT = {".mp4", ".mkv", ".webm", ".mov", ".avi", ".m4v", ".flv", ".ts", ".wmv", ".mpg", ".mpeg", ".3gp"}
AUD_EXT = {".mp3", ".m4a", ".opus", ".ogg", ".wav", ".flac", ".aac", ".wma"}
for ext, mt in {".mkv": "video/x-matroska", ".opus": "audio/ogg", ".m4a": "audio/mp4",
                ".webm": "video/webm", ".flac": "audio/flac", ".avif": "image/avif"}.items():
    mimetypes.add_type(mt, ext)

SEG = 6                                            # HLS segment length, seconds
PCT_RE = re.compile(r"(\d+(?:\.\d+)?)%")
UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120 Safari/537.36"


# --------------------------------------------------------------------------
# settings
# --------------------------------------------------------------------------
class Settings:
    host = "all"                     # all interfaces (IPv4 + IPv6); also: 0.0.0.0, ::, an address, 127.0.0.1
    port = 8765
    scheme = "http"                  # becomes "https" when TLS is active
    password = os.environ.get("MEDIA_DL_WEB_PASSWORD", "")            # fixed login from the environment (optional)
    user = os.environ.get("MEDIA_DL_WEB_LOGIN_USER", "media-dl")      # ...and its user name
    preset = "veryfast"
    cache_mb = 2048
    state = Path(os.environ.get("STATE_DIRECTORY", str(Path.home() / ".config" / "media-dl-web"))).expanduser()
    cache = Path(os.environ.get("CACHE_DIRECTORY", str(Path.home() / ".cache" / "media-dl-web"))).expanduser()
    yt_channel = "stable"            # stable | pre   (pre = yt-dlp nightly/pre-release builds on PyPI)
    kemono: dict = {}                 # filled from KEMONO_DEFAULTS below
    proxy = os.environ.get("MEDIA_DL_WEB_PROXY", "").strip()           # http://, https://, socks5://, socks5h:// ...
    proxy_downloads = True            # use it for yt-dlp, gallery-dl, direct links and image previews
    proxy_updates = os.environ.get("MEDIA_DL_WEB_PROXY_UPDATES") == "1"    # also for updates, plugins and installs
    wallpaper = False                 # persisted as a boolean, with the base64 image on the next line
    wallpaper_b64 = ""
    tmp = Path(os.environ.get("MEDIA_DL_WEB_TMP", "/var/tmp/media-dl-web"))
    outdir = Path(os.environ.get("MEDIA_DL_WEB_OUTDIR", "")) if os.environ.get("MEDIA_DL_WEB_OUTDIR") else (
        (Path.home() / "Downloads" / "media-dl-web") if (os.getuid() >= 1000 and Path.home().is_dir())
        else (Path(os.environ.get("STATE_DIRECTORY", str(Path.home() / ".config" / "media-dl-web"))) / "downloads"))


S = Settings()
LOCK = threading.RLock()


def child_env() -> dict:
    env = os.environ.copy()
    env["PATH"] = f"{BIN_DIR}:{VENV_BIN}:{env.get('PATH', '')}"      # bundled ffmpeg / venv tools first
    env["PYTHONUNBUFFERED"] = "1"
    return env


WALLPAPER_MAX = 8 * 1024 * 1024


def decode_wallpaper(b64: str) -> tuple[bytes, str]:
    """(bytes, mime) for a base64 string (a data: URL prefix is accepted). Raises ValueError."""
    b64 = (b64 or "").strip()
    if b64.startswith("data:"):
        b64 = b64.split(",", 1)[-1]
    if len(b64) > WALLPAPER_MAX * 4 // 3 + 16:
        raise ValueError("wallpaper is too large (limit 8 MB)")
    try:
        raw = base64.b64decode(b64, validate=True)
    except Exception:
        raise ValueError("wallpaper is not valid base64") from None
    if raw[:8] == b"\x89PNG\r\n\x1a\n":
        return raw, "image/png"
    if raw[:3] == b"\xff\xd8\xff":
        return raw, "image/jpeg"
    if raw[:6] in (b"GIF87a", b"GIF89a"):
        return raw, "image/gif"
    if raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        return raw, "image/webp"
    raise ValueError("wallpaper must be a PNG, JPEG, GIF or WebP image")


# --------------------------------------------------------------------------
# proxy
# --------------------------------------------------------------------------
PROXY_SCHEMES = ("http", "https", "socks4", "socks4a", "socks5", "socks5h")


def clean_proxy(raw: str) -> str:
    """Validate a proxy URL like http://host:8080 or socks5h://user:pass@host:1080 ('' = none)."""
    raw = (raw or "").strip()
    if not raw:
        return ""
    if re.search(r"[\s\x00-\x1f]", raw):
        raise ValueError("the proxy URL must not contain spaces")
    u = urlparse(raw)
    if u.scheme not in PROXY_SCHEMES or not u.hostname:
        raise ValueError("proxy must look like http://host:port or socks5://host:port (schemes: "
                         + ", ".join(PROXY_SCHEMES) + ")")
    try:
        u.port
    except ValueError:
        raise ValueError("the proxy port is not a valid number") from None
    return raw


def redact(text: str) -> str:
    """Hide the password of any proxy-style URL (scheme://user:password@host) in log text."""
    return re.sub(r"(://[^/\s:@]+:)[^@/\s]+@", r"\1***@", text)


def opener_for(proxy: str):
    """urllib opener that goes through `proxy` ('' = no explicit proxy; environment proxies still apply)."""
    if not proxy:
        return urllib.request.build_opener()
    u = urlparse(proxy)
    if u.scheme.startswith("socks"):
        try:
            import socks
            import sockshandler
        except ImportError:
            raise RuntimeError("SOCKS proxies need the PySocks package (uv pip install pysocks)") from None
        kind = socks.SOCKS4 if u.scheme.startswith("socks4") else socks.SOCKS5
        return urllib.request.build_opener(sockshandler.SocksiPyHandler(
            kind, u.hostname, u.port or 1080, u.scheme in ("socks5h", "socks4a"),
            urllib.parse.unquote(u.username or "") or None, urllib.parse.unquote(u.password or "") or None))
    return urllib.request.build_opener(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))


def job_proxy(req: dict) -> str:
    """Proxy for one download: the job's own value ('none' = direct) or the saved default."""
    p = (req.get("proxy") or "").strip()
    if p.lower() in ("none", "direct", "off"):
        return ""
    if p:
        return clean_proxy(p)
    return S.proxy if S.proxy_downloads else ""


def update_proxy() -> str:
    return S.proxy if (S.proxy and S.proxy_updates) else ""


def load_persisted() -> None:
    try:
        d = json.loads((S.state / "config.json").read_text())
    except Exception:
        return
    if d.get("outdir") and not os.environ.get("MEDIA_DL_WEB_OUTDIR"):
        S.outdir = Path(d["outdir"])
    if d.get("preset") in PRESETS:
        S.preset = d["preset"]
    if isinstance(d.get("cache_mb"), int) and 128 <= d["cache_mb"] <= 1048576:
        S.cache_mb = d["cache_mb"]
    if d.get("yt_channel") in ("stable", "pre"):
        S.yt_channel = d["yt_channel"]
    try:
        if isinstance(d.get("kemono"), dict):
            S.kemono = clean_kemono(d["kemono"])
    except ValueError:
        pass
    if "proxy" in d and not os.environ.get("MEDIA_DL_WEB_PROXY"):
        try:
            S.proxy = clean_proxy(d["proxy"])
        except ValueError:
            S.proxy = ""
    if isinstance(d.get("proxy_downloads"), bool):
        S.proxy_downloads = d["proxy_downloads"]
    if isinstance(d.get("proxy_updates"), bool) and os.environ.get("MEDIA_DL_WEB_PROXY_UPDATES") is None:
        S.proxy_updates = d["proxy_updates"]
    try:
        if d.get("wallpaper_image"):
            decode_wallpaper(d["wallpaper_image"])
            S.wallpaper_b64 = d["wallpaper_image"].split(",", 1)[-1]
        S.wallpaper = bool(d.get("wallpaper")) and bool(S.wallpaper_b64)
    except ValueError:
        S.wallpaper, S.wallpaper_b64 = False, ""


def save_persisted() -> None:
    try:
        S.state.mkdir(parents=True, exist_ok=True)
        tmp = S.state / "config.json.tmp"
        # "wallpaper" (true/false) is followed directly by "wallpaper_image" (the base64 image, one line)
        tmp.write_text(json.dumps({"outdir": str(S.outdir), "preset": S.preset, "cache_mb": S.cache_mb,
                                   "yt_channel": S.yt_channel, "kemono": S.kemono, "proxy": S.proxy,
                                   "proxy_downloads": S.proxy_downloads, "proxy_updates": S.proxy_updates,
                                   "wallpaper": S.wallpaper, "wallpaper_image": S.wallpaper_b64}, indent=2))
        os.chmod(tmp, 0o600)                              # may hold a proxy password
        os.replace(tmp, S.state / "config.json")
    except Exception:
        pass


PRESETS = ("ultrafast", "superfast", "veryfast", "faster", "fast", "medium")


def set_outdir(raw: str) -> Path:
    p = Path(str(raw or "")).expanduser()
    if not p.is_absolute():
        raise ValueError("path must be absolute")
    p.mkdir(parents=True, exist_ok=True)
    t = p / ".write-test"
    t.write_text("x")
    t.unlink()
    S.outdir = p
    save_persisted()
    return p


# --------------------------------------------------------------------------
# file tokens (opaque ids for files under the library / preview roots)
# --------------------------------------------------------------------------
def roots() -> dict[str, Path]:
    return {"lib": S.outdir, "prev": S.tmp / "previews"}


def make_token(root: str, path: Path) -> str:
    rel = os.path.relpath(path, roots()[root])
    return base64.urlsafe_b64encode(f"{root}\0{rel}".encode()).decode().rstrip("=")


def resolve_token(token: str) -> Path | None:
    try:
        raw = base64.urlsafe_b64decode(token + "=" * (-len(token) % 4)).decode()
        root, rel = raw.split("\0", 1)
        base = roots()[root].resolve()
        p = (base / rel).resolve()
        if p == base or base not in p.parents or not p.is_file():
            return None
        return p
    except Exception:
        return None


def kind_of(path: Path | str) -> str:
    e = Path(path).suffix.lower()
    return "video" if e in VID_EXT else "audio" if e in AUD_EXT else "image" if e in IMG_EXT else "other"


def file_info(root: str, path: Path) -> dict:
    st = path.stat()
    return {"name": path.name, "token": make_token(root, path), "type": kind_of(path),
            "size": st.st_size, "mtime": int(st.st_mtime)}


def list_library(limit: int = 2000) -> list[dict]:
    out = []
    base = S.outdir
    if not base.exists():
        return out
    for dirpath, _, names in os.walk(base):
        for n in names:
            p = Path(dirpath) / n
            if kind_of(p) != "other":
                try:
                    out.append(file_info("lib", p))
                except OSError:
                    pass
    out.sort(key=lambda d: d["mtime"], reverse=True)
    return out[:limit]


# --------------------------------------------------------------------------
# yt-dlp extractor list + URL routing
# --------------------------------------------------------------------------
EXT = {"loading": True, "items": [], "error": ""}
BROKEN_SUFFIX = " (CURRENTLY BROKEN)"
_ver_cache: dict = {}


def parse_extractors(text: str) -> list[dict]:
    seen, out = set(), []
    for raw in text.splitlines():
        if not raw.strip() or raw[0].isspace():
            continue
        line = raw.strip()
        broken = line.endswith(BROKEN_SUFFIX)
        if broken:
            line = line[: -len(BROKEN_SUFFIX)].rstrip()
        if line and line not in seen:
            seen.add(line)
            out.append({"name": line, "broken": broken})
    return out


def plugins_sig() -> str:
    try:
        return ",".join(f"{p.name}:{int(p.stat().st_mtime)}" for p in sorted(PLUGINS_DIR.iterdir()))
    except OSError:
        return ""


def ytdlp_version() -> str:
    cmd = ytdlp_cmd()
    if not cmd:
        return ""
    try:
        key = (tuple(cmd), Path(cmd[-1]).stat().st_mtime_ns)
    except OSError:
        key = (tuple(cmd), 0)
    if key in _ver_cache:
        return _ver_cache[key]
    try:
        v = subprocess.run(cmd + ["--version"], capture_output=True, text=True, timeout=60, env=child_env()).stdout.strip()
    except Exception:
        v = ""
    if v:
        _ver_cache[key] = v
    return v


def load_extractors(force: bool = False) -> None:
    EXT.update(loading=True, error="")
    try:
        cmd = ytdlp_cmd()
        if not cmd:
            raise RuntimeError("yt-dlp is not installed (Updates tab → yt-dlp → Install)")
        S.cache.mkdir(parents=True, exist_ok=True)
        cache = S.cache / "extractors.json"
        key = ytdlp_version() + "|" + plugins_sig()
        items = None
        if not force and cache.exists():
            try:
                d = json.loads(cache.read_text())
                if d.get("version") == key and d.get("extractors"):
                    items = d["extractors"]
            except Exception:
                pass
        if items is None:
            res = subprocess.run(cmd + ytdlp_args() + ["--list-extractors"], capture_output=True, text=True,
                                 timeout=300, env=child_env())
            items = parse_extractors(res.stdout)
            if items:
                cache.write_text(json.dumps({"version": key, "extractors": items}))
        EXT["items"] = items
        if not items:
            EXT["error"] = "yt-dlp returned no extractors"
    except Exception as e:
        EXT["error"] = str(e)
    finally:
        EXT["loading"] = False


def ytdlp_matches(url: str) -> list[str]:
    """Names of the (non-generic) extractors that claim this URL. `--list-extractors URL` prints each
    extractor and, indented under the ones that match, the URL; this also covers plugin extractors."""
    cmd = ytdlp_cmd()
    if not cmd:
        return []
    res = subprocess.run(cmd + ytdlp_args() + ["--list-extractors", url], capture_output=True, text=True,
                         timeout=120, env=child_env())
    names: list[str] = []
    cur = None
    for raw in res.stdout.splitlines():
        if not raw.strip():
            continue
        if raw[0].isspace():
            if cur and cur != "generic" and cur not in names:
                names.append(cur)
        else:
            cur = raw.strip()
            if cur.endswith(BROKEN_SUFFIX):
                cur = cur[: -len(BROKEN_SUFFIX)].rstrip()
    return names


def supported_by_ytdlp(url: str, allowed: set | None) -> bool:
    try:
        return any(allowed is None or n in allowed for n in ytdlp_matches(url))
    except Exception:
        return False


def supported_by_gdl(url: str) -> bool:
    try:
        import gallery_dl.extractor as GE
        return GE.find(url) is not None
    except Exception:
        return False


# --------------------------------------------------------------------------
# direct links (e.g. https://encrypted-tbn0.gstatic.com/images?q=tbn:...): neither tool has an extractor
# for a bare image/video URL that has no file extension, so we fetch it ourselves
# --------------------------------------------------------------------------
MAX_DIRECT = 8 * 1024 ** 3
CT_EXT = {"image/jpeg": ".jpg", "image/jpg": ".jpg", "image/png": ".png", "image/gif": ".gif", "image/webp": ".webp",
          "image/avif": ".avif", "image/bmp": ".bmp", "video/mp4": ".mp4", "video/webm": ".webm",
          "video/x-matroska": ".mkv", "video/quicktime": ".mov", "audio/mpeg": ".mp3", "audio/mp4": ".m4a",
          "audio/ogg": ".ogg", "audio/flac": ".flac", "audio/wav": ".wav", "audio/x-wav": ".wav"}


def probe_direct(url: str, timeout: int = 15, proxy: str = "") -> str:
    """Content type if the URL serves an image/video/audio file, else ''."""
    if not url.lower().startswith(("http://", "https://")):
        return ""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA, "Range": "bytes=0-0", "Accept": "*/*"})
        with opener_for(proxy).open(req, timeout=timeout) as r:
            ct = (r.headers.get("Content-Type") or "").split(";")[0].strip().lower()
            return ct if ct.startswith(("image/", "video/", "audio/")) else ""
    except Exception:
        return ""


def direct_name(url: str, headers, ct: str) -> str:
    cd = headers.get("Content-Disposition") or ""
    m = re.search(r"filename\*=(?:UTF-8'')?([^;]+)", cd, re.I) or re.search(r'filename="?([^";]+)"?', cd, re.I)
    name = urllib.parse.unquote(m.group(1).strip().strip('"')) if m else Path(urlparse(url).path).name
    name = re.sub(r"[^\w.\- ()\[\]]+", "_", name).strip(" .")[:120]
    ext = Path(name).suffix.lower()
    if ext not in IMG_EXT | VID_EXT | AUD_EXT:
        stem = Path(name).stem if name else ""
        ext = CT_EXT.get(ct) or mimetypes.guess_extension(ct) or ".bin"
        if stem.lower() in ("", "images", "image", "download", "file", "get", "view"):
            stem = "image" if ct.startswith("image/") else "media"
        name = f"{stem}-{hashlib.sha1(url.encode()).hexdigest()[:8]}{ext}"
    return name


def run_direct(job, outdir: Path) -> int:
    """Download job.url as a plain file into outdir/direct/. Returns 0 on success."""
    try:
        if not job.url.lower().startswith(("http://", "https://")):
            raise RuntimeError("direct download needs an http(s) URL")
        dest_dir = outdir / "direct"
        dest_dir.mkdir(parents=True, exist_ok=True)
        job.add_log(f"$ direct download {job.url}" + (f"  (via proxy {redact(job.proxy)})" if job.proxy else ""))
        req = urllib.request.Request(job.url, headers={"User-Agent": UA, "Accept": "*/*"})
        with opener_for(job.proxy).open(req, timeout=30) as r:
            ct = (r.headers.get("Content-Type") or "").split(";")[0].strip().lower()
            if ct in ("text/html", "application/xhtml+xml"):
                raise RuntimeError("the URL returned a web page (text/html), not a file")
            total = int(r.headers.get("Content-Length") or 0)
            dest = dest_dir / direct_name(job.url, r.headers, ct)
            n = 1
            while dest.exists():
                dest = dest_dir / f"{dest.stem}-{n}{dest.suffix}"
                n += 1
            tmp = dest.with_name(dest.name + ".part")
            got = 0
            with open(tmp, "wb") as f:
                while True:
                    if job.cancelled:
                        raise RuntimeError("cancelled")
                    chunk = r.read(256 * 1024)
                    if not chunk:
                        break
                    f.write(chunk)
                    got += len(chunk)
                    if total:
                        job.progress = got * 100.0 / total
                    if got > MAX_DIRECT:
                        raise RuntimeError("file is larger than 8 GiB, aborting")
            os.replace(tmp, dest)
        job.add_log(f"saved {dest.name} ({got // 1024} KiB, {ct or 'unknown type'})")
        job.add_file(dest)
        return 0
    except Exception as e:
        job.last_error = f"ERROR: {e}"
        job.add_log(job.last_error)
        return 1


# --------------------------------------------------------------------------
# Kemono / Coomer through gallery-dl (its built-in extractors; no extra program needed)
# --------------------------------------------------------------------------
KEMONO_FILES = ("attachments", "file", "inline")
KEMONO_DEFAULTS = {"files": list(KEMONO_FILES), "comments": False, "dms": False, "duplicates": False,
                   "announcements": False, "revisions": "false", "max_posts": "", "sleep": "",
                   "write_json": False, "cookies": "", "subfolder": "kemono"}


S.kemono = dict(KEMONO_DEFAULTS)


def clean_kemono(d: dict) -> dict:
    """Validate the Kemono options (raises ValueError) and return a clean copy."""
    out = dict(KEMONO_DEFAULTS)
    if "files" in d:
        files = [f for f in (d["files"] or []) if f in KEMONO_FILES]
        if not files:
            raise ValueError("pick at least one file kind (attachments / file / inline)")
        out["files"] = files
    for k in ("comments", "dms", "duplicates", "announcements", "write_json"):
        if k in d:
            out[k] = bool(d[k])
    if d.get("revisions", "false") not in ("false", "true", "unique"):
        raise ValueError("revisions must be false, true or unique")
    out["revisions"] = d.get("revisions", "false")
    mp = str(d.get("max_posts", "")).strip()
    if mp and not (mp.isdigit() and 1 <= int(mp) <= 100000):
        raise ValueError("max posts must be a number (or empty for all)")
    out["max_posts"] = mp
    sl = str(d.get("sleep", "")).strip()
    if sl:
        try:
            if not 0 <= float(sl) <= 60:
                raise ValueError
        except ValueError:
            raise ValueError("sleep must be a number of seconds between 0 and 60") from None
    out["sleep"] = sl
    sub = str(d.get("subfolder", "kemono")).strip()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 ._-]{0,59}", sub):
        raise ValueError("folder name: letters, digits, space . _ - only")
    out["subfolder"] = sub
    out["cookies"] = str(d.get("cookies", "")).strip()
    return out


def kemono_args(k: dict) -> list[str]:
    a = ["-o", "files=" + json.dumps(k["files"])]
    for key in ("comments", "dms", "duplicates", "announcements"):
        a += ["-o", f"{key}={'true' if k[key] else 'false'}"]
    if k["revisions"] != "false":
        a += ["-o", f"revisions={k['revisions']}"]
    if k["max_posts"]:
        a += ["-o", f"max-posts={k['max_posts']}"]
    if k["sleep"]:
        a += ["--sleep-request", k["sleep"]]
    if k["write_json"]:
        a.append("--write-metadata")
    if k["cookies"]:
        a += ["--cookies", k["cookies"]]
    return a


# --------------------------------------------------------------------------
# previews live in their own temp folder per preview and are deleted when the preview is closed
# --------------------------------------------------------------------------
def preview_dir(jid: str) -> Path:
    return roots()["prev"] / jid


def in_library(rel: str) -> bool:
    """Is this file (relative path as downloaded) already in the library? yt-dlp names carry the video id
    in [brackets], so the same video counts as present even when the title or extension differs."""
    dest = S.outdir / rel
    if dest.exists():
        return True
    m = re.search(r"\[([^\[\]]{4,})\]\.[A-Za-z0-9]{1,5}$", Path(rel).name)
    if m and dest.parent.is_dir():
        key = f"[{m.group(1)}]"
        try:
            return any(key in n for n in os.listdir(dest.parent))
        except OSError:
            return False
    return False


def discard_preview(jid: str) -> bool:
    with LOCK:
        j = JOBS.pop(jid, None)
    if j:
        j.cancelled = True
        if j.proc and j.proc.poll() is None:
            try:
                os.killpg(j.proc.pid, signal.SIGTERM)
            except OSError:
                j.proc.terminate()
    shutil.rmtree(preview_dir(jid), ignore_errors=True)
    return j is not None


def save_preview(j) -> list[dict]:
    """Copy the preview's files into the library (the temp copy stays until the preview is closed)."""
    base = preview_dir(j.id).resolve()
    saved = []
    for f in list(j.files):
        p = resolve_token(f["token"])
        if not p:
            continue
        rel = os.path.relpath(p, base)
        if in_library(rel):
            continue
        dest = S.outdir / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, dest)
        saved.append(file_info("lib", dest))
    return saved


def cleanup_previews(max_age: int = 6 * 3600) -> None:
    root = roots()["prev"]
    try:
        with LOCK:
            live = {k for k, j in JOBS.items() if j.state == "running"}
        for d in root.iterdir():
            if d.name not in live and time.time() - d.stat().st_mtime > max_age:
                shutil.rmtree(d, ignore_errors=True)
                JOBS.pop(d.name, None)
    except OSError:
        pass


# --------------------------------------------------------------------------
# jobs (downloads / previews)
# --------------------------------------------------------------------------
class Job:
    def __init__(self, req: dict):
        self.id = secrets.token_hex(6)
        self.req = req
        self.url = req["url"]
        self.preview = bool(req.get("preview"))
        try:
            self.proxy = job_proxy(req)
        except ValueError:
            self.proxy = ""
        self.state = "running"          # running | done | failed | cancelled | error
        self.level = ""                 # "" | ok | error   (status colour)
        self.message = "Starting…"
        self.progress = 0.0
        self.log: list[str] = []
        self.files: list[dict] = []
        self.urls: list[str] = []       # image-preview URLs
        self.fail_msgs: list[str] = []
        self.last_error = ""
        self.cancelled = False
        self.proc: subprocess.Popen | None = None
        self.created = time.time()
        self.lock = threading.Lock()

    def add_log(self, line: str) -> None:
        line = redact(line)
        with self.lock:
            self.log.append(line)
            if len(self.log) > 6000:
                del self.log[:1000]
                self.log_offset = getattr(self, "log_offset", 0) + 1000

    def add_file(self, path: Path) -> None:
        root = "prev" if self.preview else "lib"
        try:
            info = file_info(root, path)
            if self.preview:
                info["rel"] = os.path.relpath(path, preview_dir(self.id))
            with self.lock:
                if all(f["token"] != info["token"] for f in self.files):
                    self.files.append(info)
        except Exception:
            pass

    def view(self, log_from: int = 0) -> dict:
        with self.lock:
            off = getattr(self, "log_offset", 0)
            start = max(0, log_from - off)
            files = [dict(f) for f in self.files]
            if self.preview:
                for f in files:
                    f["in_library"] = in_library(f.get("rel", f["name"]))
            return {"id": self.id, "url": self.url, "preview": self.preview, "state": self.state,
                    "level": self.level, "message": self.message, "progress": self.progress,
                    "files": files, "image_count": len(self.urls),
                    "log": self.log[start:], "log_next": off + len(self.log)}


JOBS: dict[str, Job] = {}


def new_job(req: dict) -> Job:
    job = Job(req)
    with LOCK:
        JOBS[job.id] = job
        for jid in sorted(JOBS, key=lambda k: JOBS[k].created)[:-30]:       # keep the last 30
            if JOBS[jid].state != "running":
                shutil.rmtree(preview_dir(jid), ignore_errors=True)
                del JOBS[jid]
    threading.Thread(target=run_job, args=(job,), daemon=True).start()
    return job


def decide(job: Job) -> list[str]:
    r = job.req
    mode = r.get("mode", "auto")
    if mode in ("video", "image", "direct"):
        return [mode]
    allowed = set(r.get("selected") or []) if (r.get("restrict") and r.get("selected")) else None
    v = supported_by_ytdlp(job.url, allowed)
    g = supported_by_gdl(job.url)
    job.add_log(f"auto-detect: yt-dlp={'yes' if v else 'no'}  gallery-dl={'yes' if g else 'no'}")
    tie = r.get("tie", "video")
    if v and g:
        return ["video", "image"] if tie == "both" else [tie]
    if v:
        return ["video"]
    if g:
        return ["image"]
    ct = probe_direct(job.url, proxy=job.proxy)
    if ct:
        job.add_log(f"no extractor claims this URL, but it serves a {ct} file: downloading it directly")
        return ["direct"]
    job.add_log("no dedicated extractor found, trying yt-dlp")
    return ["video"]


def build_cmd(job: Job, kind: str, outdir: Path) -> list[str]:
    r = job.req
    extra_args = os.environ.get("MEDIA_DL_WEB_NO_EXTRA_ARGS") != "1"
    cookies = (r.get("cookies") or "").strip()
    if kind == "video":
        base = ytdlp_cmd()
        if not base:
            raise RuntimeError("yt-dlp is not installed (Updates tab → yt-dlp → Install)")
        fmt = (r.get("format") or "b").strip()
        cmd = base + ytdlp_args()
        cmd += ["--newline", "--progress", "--no-simulate", "--print", "after_move:filepath",
                "-P", str(outdir), "-o", "%(extractor)s/%(title).150B [%(id)s].%(ext)s", "-f", fmt]
        if r.get("noplaylist", True) or job.preview:
            cmd.append("--no-playlist")
        if r.get("restrict") and r.get("selected"):
            names = [re.escape(n.lower()) for n in r["selected"]]
            if r.get("generic"):
                names.append("generic")
            cmd += ["--use-extractors", ",".join(names)]
        if cookies:
            cmd += ["--cookies", cookies]
        if job.proxy:
            cmd += ["--proxy", job.proxy]
        if extra_args and (r.get("ytx") or "").strip():
            cmd += shlex.split(r["ytx"])
    else:
        cmd = [GDL, "-d", str(outdir)]
        if r.get("kemono"):
            cmd += kemono_args(S.kemono)
        elif cookies:
            cmd += ["--cookies", cookies]
        if job.proxy:
            cmd += ["--proxy", job.proxy]
        if extra_args and (r.get("gdx") or "").strip():
            cmd += shlex.split(r["gdx"])
    cmd.append(job.url)
    return cmd


def run_proc(job: Job, cmd: list[str]) -> int:
    job.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                errors="replace", bufsize=1, env=child_env(), stdin=subprocess.DEVNULL,
                                start_new_session=True)
    assert job.proc.stdout is not None
    for line in job.proc.stdout:
        line = line.rstrip("\n")
        job.add_log(line)
        low = line.lower()
        if low.startswith("error") or "[error]" in low:
            job.last_error = line.strip()
        if "[download]" in line:
            m = PCT_RE.search(line)
            if m:
                job.progress = float(m.group(1))
        p = line[2:] if line.startswith("# ") else line      # gallery-dl: "# path" = already existed
        if p.startswith("/") and os.path.isfile(p):
            job.add_file(Path(p))
    return job.proc.wait()


def image_preview(job: Job) -> None:
    cmd = [GDL, "-g", "--range", "1-12"]
    c = (job.req.get("cookies") or "").strip()
    if c:
        cmd += ["--cookies", c]
    if job.proxy:
        cmd += ["--proxy", job.proxy]
    cmd.append(job.url)
    job.add_log("$ " + shlex.join(cmd))
    res = subprocess.run(cmd, capture_output=True, text=True, timeout=180, env=child_env())
    job.urls = [l.strip() for l in res.stdout.splitlines() if l.strip().startswith(("http://", "https://"))][:12]
    if not job.urls:
        job.add_log((res.stderr or "")[-500:])
        raise RuntimeError("gallery-dl returned no direct image URLs")


def run_job(job: Job) -> None:
    results: list[tuple[str, int]] = []
    error = ""
    try:
        kinds = decide(job)
        if job.preview:
            kinds = kinds[:1]
        if job.preview:
            outdir = preview_dir(job.id)
        elif job.req.get("kemono"):
            outdir = S.outdir / S.kemono["subfolder"]
        else:
            outdir = S.outdir
        for kind in kinds:
            if job.cancelled:
                break
            tool = {"video": "yt-dlp", "image": "gallery-dl", "direct": "direct download"}[kind]
            if job.preview and kind == "image":
                job.message = "Fetching image previews…"
                image_preview(job)
                results.append((tool, 0))
                continue
            outdir.mkdir(parents=True, exist_ok=True)
            job.message = f"{tool} running…"
            job.last_error = ""
            if kind == "direct":
                rc = run_direct(job, outdir)
            else:
                cmd = build_cmd(job, kind, outdir)
                job.add_log("$ " + shlex.join(cmd))
                rc = run_proc(job, cmd)
                job.add_log(f"[exit code {rc}]")
                if rc != 0 and not job.cancelled and "unsupported url" in job.last_error.lower():
                    ct = probe_direct(job.url, proxy=job.proxy)
                    if ct:
                        job.add_log(f"{tool} does not support this URL, but it serves a {ct} file: trying a direct download")
                        job.last_error = ""
                        if run_direct(job, outdir) == 0:
                            rc, tool = 0, "direct download"
            results.append((tool, rc))
            if rc != 0 and not job.cancelled:
                msg = f"{tool} failed (exit code {rc})"
                if job.last_error:
                    msg += f": {job.last_error[:140]}"
                job.fail_msgs.append(msg)
                job.message, job.level = msg, "error"
    except Exception as e:
        error = str(e)
        job.add_log(f"error: {e}")
    failed = [(t, rc) for t, rc in results if rc != 0]
    if job.cancelled:
        job.state, job.level, job.message = "cancelled", "", "Cancelled"
    elif error:
        job.state, job.level, job.message = "error", "error", f"Error: {error[:160]} (see Log)"
    elif failed:
        msgs = job.fail_msgs or [f"{t} failed (exit code {rc})" for t, rc in failed]
        job.state, job.level = "failed", "error"
        job.message = "FAILED: " + " | ".join(msgs) + "  (see Log)"
    else:
        n = len(job.files) or len(job.urls)
        job.state, job.level = "done", "ok"
        job.progress = 100.0
        job.message = (f"Done (exit code 0): {n} file(s)" if n
                       else "Done (exit code 0), but no files were reported (see Log)")


# --------------------------------------------------------------------------
# playback: probe, direct-play decision, on-the-fly HLS
# --------------------------------------------------------------------------
_probe_cache: dict = {}


def probe(path: Path) -> dict:
    key = (str(path), path.stat().st_mtime_ns)
    if key in _probe_cache:
        return _probe_cache[key]
    res = subprocess.run([FFPROBE, "-v", "error", "-print_format", "json", "-show_format", "-show_streams",
                          str(path)], capture_output=True, text=True, timeout=60)
    d = json.loads(res.stdout or "{}")
    v = next((s for s in d.get("streams", []) if s.get("codec_type") == "video"
              and s.get("disposition", {}).get("attached_pic") != 1), None)
    a = next((s for s in d.get("streams", []) if s.get("codec_type") == "audio"), None)
    dur = float(d.get("format", {}).get("duration") or (v or a or {}).get("duration") or 0)
    info = {"duration": dur, "has_video": v is not None, "has_audio": a is not None,
            "vcodec": (v or {}).get("codec_name", ""), "acodec": (a or {}).get("codec_name", ""),
            "pix_fmt": (v or {}).get("pix_fmt", ""), "profile": (v or {}).get("profile", ""),
            "width": (v or {}).get("width", 0), "height": (v or {}).get("height", 0),
            "format": d.get("format", {}).get("format_name", "")}
    _probe_cache[key] = info
    return info


def direct_ok(info: dict, ext: str) -> bool:
    """Would a typical browser play this file as-is?"""
    ext = ext.lower()
    if not info["has_video"]:
        return ext in {".mp3", ".m4a", ".ogg", ".opus", ".wav", ".flac", ".aac"} and \
            info["acodec"] in {"mp3", "aac", "opus", "vorbis", "flac", "pcm_s16le"}
    if ext in {".mp4", ".m4v", ".mov"}:
        return (info["vcodec"] == "h264" and info["pix_fmt"] in {"yuv420p", "yuvj420p"}
                and "10" not in info["profile"] and "4:2" not in info["profile"] and "4:4" not in info["profile"]
                and info["acodec"] in {"", "aac", "mp3"})
    if ext == ".webm":
        return info["vcodec"] in {"vp8", "vp9", "av1"} and info["acodec"] in {"", "opus", "vorbis"}
    return False


_seg_locks: dict[str, threading.Lock] = {}
_pool = ThreadPoolExecutor(max_workers=int(os.environ.get("MEDIA_DL_WEB_WORKERS", "2")))


def seg_path(path: Path, maxh: int, n: int) -> Path:
    key = hashlib.sha1(f"{path}|{path.stat().st_mtime_ns}|{maxh}|{n}".encode()).hexdigest()
    return S.cache / "hls" / key[:2] / f"{key}.ts"


def make_segment(path: Path, maxh: int, n: int) -> Path:
    info = probe(path)
    out = seg_path(path, maxh, n)
    if out.exists():
        return out
    with LOCK:
        lk = _seg_locks.setdefault(str(out), threading.Lock())
    with lk:
        if out.exists():
            return out
        out.parent.mkdir(parents=True, exist_ok=True)
        start = n * SEG
        dur = max(0.1, min(SEG, info["duration"] - start))
        tmp = out.with_suffix(".tmp")
        cmd = [FFMPEG, "-nostdin", "-v", "error", "-ss", f"{start:.3f}", "-i", str(path), "-t", f"{dur:.3f}", "-sn", "-dn"]
        if info["has_video"]:
            cmd += ["-map", "0:v:0", "-vf", f"scale=-2:'min({maxh},ih)',format=yuv420p",
                    "-c:v", "libx264", "-preset", S.preset, "-crf", "23", "-profile:v", "high",
                    "-g", "48", "-sc_threshold", "0", "-threads", "0"]
            if info["has_audio"]:
                cmd += ["-map", "0:a:0", "-c:a", "aac", "-b:a", "160k", "-ac", "2"]
        else:
            cmd += ["-map", "0:a:0", "-vn", "-c:a", "aac", "-b:a", "160k", "-ac", "2"]
        cmd += ["-output_ts_offset", f"{start:.3f}", "-f", "mpegts", "-y", str(tmp)]
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        if res.returncode != 0 or not tmp.exists() or tmp.stat().st_size == 0:
            tmp.unlink(missing_ok=True)
            raise RuntimeError(f"ffmpeg failed: {(res.stderr or '')[-300:]}")
        os.replace(tmp, out)
    return out


def prefetch(path: Path, maxh: int, n: int, total: int) -> None:
    for k in (n + 1, n + 2):
        if k < total and not seg_path(path, maxh, k).exists():
            _pool.submit(lambda kk=k: _safe(make_segment, path, maxh, kk))


def _safe(fn, *a):
    try:
        fn(*a)
    except Exception:
        pass


def playlist(path: Path) -> str:
    info = probe(path)
    dur = info["duration"]
    n = max(1, int(-(-dur // SEG)))
    lines = ["#EXTM3U", "#EXT-X-VERSION:3", f"#EXT-X-TARGETDURATION:{SEG}", "#EXT-X-MEDIA-SEQUENCE:0",
             "#EXT-X-PLAYLIST-TYPE:VOD"]
    for i in range(n):
        d = min(SEG, dur - i * SEG) if dur else SEG
        lines += [f"#EXTINF:{max(d, 0.1):.3f},", f"seg{i}.ts"]
    lines.append("#EXT-X-ENDLIST")
    return "\n".join(lines) + "\n"


def thumb(path: Path) -> Path:
    key = hashlib.sha1(f"{path}|{path.stat().st_mtime_ns}".encode()).hexdigest()
    out = S.cache / "thumbs" / key[:2] / f"{key}.jpg"
    if out.exists():
        return out
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = [FFMPEG, "-nostdin", "-v", "error"]
    if kind_of(path) in ("video",):
        try:
            d = probe(path)["duration"]
        except Exception:
            d = 0
        cmd += ["-ss", f"{min(3.0, d / 3) if d else 0:.2f}"]
    cmd += ["-i", str(path), "-frames:v", "1", "-vf", "scale=320:-2", "-an", "-y", str(out)]
    res = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    if res.returncode != 0 or not out.exists():
        raise RuntimeError("thumbnail failed")
    return out


def trim_cache() -> None:
    try:
        files = [(p, p.stat()) for sub in ("hls", "thumbs") for p in (S.cache / sub).rglob("*") if p.is_file()]
        now = time.time()
        for p, st in files:
            if p.suffix == ".tmp" and now - st.st_mtime > 600:
                p.unlink(missing_ok=True)
        files = [(p, st) for p, st in files if p.exists()]
        total = sum(st.st_size for _, st in files)
        limit = S.cache_mb * 1024 * 1024
        for p, st in sorted(files, key=lambda x: x[1].st_mtime):
            if total <= limit and now - st.st_mtime < 24 * 3600:
                break
            total -= st.st_size
            p.unlink(missing_ok=True)
    except Exception:
        pass


def ensure_tmp() -> None:
    """Pick a writable temp location (default /var/tmp/media-dl-web) and start with no leftover previews."""
    for cand in (S.tmp, Path(tempfile.gettempdir()) / f"media-dl-web-{os.getuid()}"):
        try:
            (cand / "previews").mkdir(parents=True, exist_ok=True)
            S.tmp = cand
            break
        except OSError:
            continue
    shutil.rmtree(S.tmp / "previews", ignore_errors=True)
    (S.tmp / "previews").mkdir(parents=True, exist_ok=True)


def janitor() -> None:
    while True:
        trim_cache()
        cleanup_previews()
        time.sleep(600)


# --------------------------------------------------------------------------
# tasks: installs / updates (same log + state model as download jobs)
# --------------------------------------------------------------------------
class Task:
    def __init__(self, title: str, echo: bool = False):
        self.id = secrets.token_hex(6)
        self.title = title
        self.state = "running"          # running | done | failed
        self.level = ""
        self.message = title + "…"
        self.log: list[str] = []
        self.log_offset = 0
        self.created = time.time()
        self.echo = echo                # CLI mode: also print
        self.lock = threading.Lock()

    def add_log(self, line: str) -> None:
        line = redact(line)
        if self.echo:
            print(line, flush=True)
        with self.lock:
            self.log.append(line)
            if len(self.log) > 4000:
                del self.log[:1000]
                self.log_offset += 1000

    def view(self, log_from: int = 0) -> dict:
        with self.lock:
            start = max(0, log_from - self.log_offset)
            return {"id": self.id, "title": self.title, "state": self.state, "level": self.level,
                    "message": self.message, "log": self.log[start:], "log_next": self.log_offset + len(self.log)}


TASKS: dict[str, Task] = {}


def run_task(t: Task, fn, *args) -> None:
    try:
        fn(t, *args)
        if t.state == "running":
            t.state, t.level, t.message = "done", "ok", "Done"
    except Exception as e:
        t.add_log(f"error: {e}")
        t.state, t.level, t.message = "failed", "error", f"FAILED: {str(e)[:200]}"


def start_task(title: str, fn, *args) -> Task:
    t = Task(title)
    with LOCK:
        TASKS[t.id] = t
        for tid in sorted(TASKS, key=lambda k: TASKS[k].created)[:-20]:
            if TASKS[tid].state != "running":
                del TASKS[tid]
    threading.Thread(target=run_task, args=(t, fn, *args), daemon=True).start()
    return t


def http_get(url: str, timeout: int = 30, max_bytes: int = 100_000_000, accept: str = "*/*") -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "media-dl-web/" + VERSION, "Accept": accept})
    with opener_for(update_proxy()).open(req, timeout=timeout) as r:
        data = r.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise RuntimeError(f"download from {urlparse(url).netloc} is larger than {max_bytes // 1_000_000} MB, aborting")
    return data


def http_json(url: str, timeout: int = 20):
    return json.loads(http_get(url, timeout, 20_000_000, "application/json"))


def uv_bin() -> str | None:
    for c in (VENV_BIN / "uv", shutil.which("uv")):
        if c and Path(c).exists():
            return str(c)
    return None


def pip_cmd(python: Path, args: list[str]) -> list[str]:
    uv = uv_bin()
    if uv:
        return [uv, "pip", "install", "--python", str(python), *args]
    return [str(python), "-m", "pip", "install", "--disable-pip-version-check",
            *["--force-reinstall" if a == "--reinstall" else a for a in args]]


def run_cmd(t: Task, cmd: list[str], cwd: Path | None = None) -> int:
    t.add_log("$ " + shlex.join(cmd))
    env = child_env()
    env.update(UV_LINK_MODE="copy", UV_PYTHON_DOWNLOADS="never")
    if update_proxy():                                  # pip, uv and friends read these
        for k in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy"):
            env[k] = update_proxy()
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace",
                         bufsize=1, env=env, cwd=cwd, stdin=subprocess.DEVNULL)
    assert p.stdout is not None
    for line in p.stdout:
        t.add_log(line.rstrip("\n"))
    rc = p.wait()
    t.add_log(f"[exit code {rc}]")
    return rc


def purge_modules() -> None:
    """After yt-dlp / gallery-dl changed on disk, make the next in-process import see the new code."""
    for m in [m for m in sys.modules if m.split(".")[0] in ("yt_dlp", "gallery_dl", "yt_dlp_ejs")]:
        del sys.modules[m]
    importlib.invalidate_caches()


def installed_version(dist: str) -> str:
    try:
        return importlib.metadata.version(dist)
    except Exception:
        return ""


def pypi_latest(name: str, pre: bool = False) -> str:
    d = http_json(f"https://pypi.org/pypi/{name}/json")
    if not pre:
        return d["info"]["version"]
    best = None
    for ver, files in d["releases"].items():
        files = [f for f in files if not f.get("yanked")]
        if files:
            t = max(f["upload_time_iso_8601"] for f in files)
            if best is None or t > best[0]:
                best = (t, ver)
    return best[1] if best else d["info"]["version"]


# ---- hls.js (the browser-side player library) -------------------------------
def hls_installed() -> str:
    try:
        return (VENDOR_DIR / "hls.version").read_text().strip() if (VENDOR_DIR / "hls.min.js").is_file() else ""
    except OSError:
        return ""


def update_hls(t: Task) -> None:
    try:
        ver = http_json("https://registry.npmjs.org/hls.js/latest")["version"]
    except Exception as e:
        ver = "1.5.17"
        t.add_log(f"could not ask npm for the latest version ({e}); using {ver}")
    url = f"https://cdn.jsdelivr.net/npm/hls.js@{ver}/dist/hls.min.js"
    t.add_log(f"downloading {url}")
    data = http_get(url, 60, 6_000_000)
    if len(data) < 100_000 or b"Hls" not in data:
        raise RuntimeError("downloaded file does not look like hls.js")
    VENDOR_DIR.mkdir(parents=True, exist_ok=True)
    tmp = VENDOR_DIR / "hls.min.js.tmp"
    tmp.write_bytes(data)
    os.replace(tmp, VENDOR_DIR / "hls.min.js")
    (VENDOR_DIR / "hls.version").write_text(ver)
    t.add_log(f"installed hls.js {ver} ({len(data) // 1024} KiB, sha256 {hashlib.sha256(data).hexdigest()[:16]}…)")


# ---- yt-dlp: the official release file; it updates itself with `yt-dlp -U` -------------
def download_ytdlp(t: Task, nightly: bool) -> None:
    """Fetch the release file (what `curl -L .../releases/latest/download/yt-dlp` gives you) into BIN_DIR."""
    repo = "yt-dlp/yt-dlp-nightly-builds" if nightly else "yt-dlp/yt-dlp"
    base = f"https://github.com/{repo}/releases/latest/download"
    t.add_log(f"downloading {base}/yt-dlp")
    data = http_get(f"{base}/yt-dlp", 120, 60_000_000)
    if data[:4] != b"PK\x03\x04" or len(data) < 500_000:
        raise RuntimeError("the download is not the yt-dlp release file")
    want = ""
    try:
        sums = http_get(f"{base}/SHA2-256SUMS", 30, 300_000).decode(errors="replace")
        want = next((l.split()[0] for l in sums.splitlines() if l.split()[-1:] == ["yt-dlp"]), "")
    except Exception as e:
        t.add_log(f"(could not fetch the checksum list: {e})")
    got = hashlib.sha256(data).hexdigest()
    if want and want != got:
        raise RuntimeError("SHA-256 mismatch: refusing to install the downloaded file")
    t.add_log(f"sha256 {got[:16]}… " + ("(verified against SHA2-256SUMS)" if want else "(not verified)"))
    BIN_DIR.mkdir(parents=True, exist_ok=True)
    tmp = BIN_DIR / "yt-dlp.new"
    tmp.write_bytes(data)
    tmp.chmod(0o755)
    os.replace(tmp, BIN_DIR / "yt-dlp")
    _ver_cache.clear()


def refresh_ytdlp_deps(t: Task) -> None:
    """The release file has no third-party add-ons built in. Install the ones yt-dlp can use (curl_cffi for
    impersonation, brotli, pycryptodomex, websockets, ...) with the version ranges the current yt-dlp wants,
    then drop the pip copy of yt-dlp itself: the release file is the real one."""
    py = VENV_BIN / "python"
    if not py.exists():
        return
    t.add_log("refreshing yt-dlp's Python add-ons (curl_cffi, brotli, ...)")
    if run_cmd(t, pip_cmd(py, ["-U", "yt-dlp[default,curl-cffi,secretstorage]"])) != 0:
        t.add_log("(add-on refresh failed; the existing ones stay in place)")
    uv = uv_bin()
    run_cmd(t, [uv, "pip", "uninstall", "--python", str(py), "yt-dlp"] if uv
            else [str(py), "-m", "pip", "uninstall", "-y", "yt-dlp"])


def update_ytdlp(t: Task, reinstall: bool = False) -> None:
    pre = S.yt_channel == "pre"
    before = ytdlp_version()
    done = False
    if (BIN_DIR / "yt-dlp").is_file() and not reinstall:
        cmd = ytdlp_cmd() + (["--proxy", update_proxy()] if update_proxy() else []) + \
              (["--update-to", "nightly"] if pre else ["-U"])
        if run_cmd(t, cmd) == 0:
            done = True
        else:
            t.add_log("`yt-dlp -U` did not work; downloading the release file instead")
    if not done:
        download_ytdlp(t, pre)
    _ver_cache.clear()
    refresh_ytdlp_deps(t)
    t.add_log(f"yt-dlp: {before or 'not installed'} -> {ytdlp_version() or '?'}" + ("  (nightly channel)" if pre else ""))
    if not t.echo:
        threading.Thread(target=load_extractors, args=(True,), daemon=True).start()


def update_gdl(t: Task, reinstall: bool = False) -> None:
    """gallery-dl is a normal Python package in the app venv: `uv pip install -U` is the update command."""
    before = installed_version("gallery-dl")
    args = (["--reinstall"] if reinstall else ["-U"]) + ["gallery-dl"]
    if run_cmd(t, pip_cmd(VENV_BIN / "python", args)) != 0:
        raise RuntimeError("gallery-dl update failed")
    purge_modules()
    t.add_log(f"gallery-dl: {before or '?'} -> {installed_version('gallery-dl') or '?'}")


# ---- ffmpeg: optional bundled static build (used when the system has none) --------------------
FFMPEG_ARCH = {"x86_64": "amd64", "aarch64": "arm64", "armv7l": "armhf", "armv6l": "armhf", "i686": "i686", "i386": "i686"}


def install_ffmpeg(t: Task) -> None:
    import platform
    import tarfile
    arch = FFMPEG_ARCH.get(platform.machine())
    if not arch:
        raise RuntimeError(f"no static ffmpeg build is known for {platform.machine()}; install ffmpeg with your package manager")
    url = f"https://johnvansickle.com/ffmpeg/releases/ffmpeg-release-{arch}-static.tar.xz"
    t.add_log(f"downloading {url} (about 40 MB)")
    data = http_get(url, 900, 250_000_000)
    try:
        want = http_get(url + ".md5", 30, 10_000).decode().split()[0]
    except Exception as e:
        want = ""
        t.add_log(f"(could not fetch the checksum: {e})")
    if want and hashlib.md5(data).hexdigest() != want:
        raise RuntimeError("ffmpeg download: MD5 mismatch, refusing to install it")
    BIN_DIR.mkdir(parents=True, exist_ok=True)
    got = []
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:xz") as tf:
        for m in tf.getmembers():
            name = Path(m.name).name
            if m.isfile() and name in ("ffmpeg", "ffprobe"):
                tmp = BIN_DIR / (name + ".new")
                with tf.extractfile(m) as src, open(tmp, "wb") as out:      # only these two files are read, nothing else is unpacked
                    shutil.copyfileobj(src, out)
                os.chmod(tmp, 0o755)
                os.replace(tmp, BIN_DIR / name)
                got.append(name)
    if sorted(got) != ["ffmpeg", "ffprobe"]:
        raise RuntimeError("the archive did not contain ffmpeg and ffprobe")
    t.add_log(f"installed {', '.join(got)} into {BIN_DIR}")


# ---- yt-dlp plugins -------------------------------------------------------------------------
PLUGIN_NAME_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}")
PIP_SPEC_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,80}([=<>!~]=?[A-Za-z0-9.*+!_-]+)?")


def plugins_enabled() -> bool:
    return os.environ.get("MEDIA_DL_WEB_NO_EXTRA_ARGS") != "1"       # plugins run code: same switch as extra args


def plugin_files(d: Path) -> list[str]:
    out = []
    for kind in ("extractor", "postprocessor"):
        k = d / "yt_dlp_plugins" / kind
        if k.is_dir():
            out += [f"{kind}/{p.name}" for p in sorted(k.glob("*.py")) if p.name != "__init__.py"]
    return out


def pip_plugins() -> list[dict]:
    res = []
    try:
        for dist in importlib.metadata.distributions():
            if any(str(f).startswith("yt_dlp_plugins/") for f in (dist.files or [])):
                res.append({"name": dist.metadata["Name"] or "?", "version": dist.version})
    except Exception:
        pass
    return res


def plugins_list() -> dict:
    items = []
    if PLUGINS_DIR.is_dir():
        for d in sorted(PLUGINS_DIR.iterdir()):
            if d.is_dir() and not d.name.startswith("."):
                try:
                    src = json.loads((d / ".source.json").read_text())
                except Exception:
                    src = {}
                items.append({"name": d.name, "kind": "folder", "files": plugin_files(d),
                              "source": src.get("source", ""), "added": src.get("added", 0)})
    for p in pip_plugins():
        items.append({"name": p["name"], "kind": "pip", "version": p["version"], "files": [], "source": "pip"})
    return {"plugins": items, "enabled": plugins_enabled(), "dir": str(PLUGINS_DIR)}


def extract_plugin_zip(data: bytes, name: str, source: str) -> list[str]:
    """Unpack the yt_dlp_plugins/ folder of a zip (at its top level or one folder down, as in GitHub archives)
    into PLUGINS_DIR/<name>/. Returns the plugin files found."""
    if not PLUGIN_NAME_RE.fullmatch(name):
        raise ValueError("bad plugin name (letters, digits, . _ - only)")
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        infos = z.infolist()
        if sum(i.file_size for i in infos) > 60_000_000:
            raise ValueError("the archive is too large")
        prefix = None
        for i in infos:
            parts = Path(i.filename).parts
            for idx in range(min(3, len(parts))):
                if parts[idx] == "yt_dlp_plugins":
                    if prefix is None or idx < len(prefix):
                        prefix = parts[:idx]
                    break
        if prefix is None:
            raise ValueError("no yt_dlp_plugins folder found in the archive (is it a yt-dlp plugin?)")
        PLUGINS_DIR.mkdir(parents=True, exist_ok=True)
        stage = PLUGINS_DIR / f".new-{name}"
        shutil.rmtree(stage, ignore_errors=True)
        for i in infos:
            parts = Path(i.filename).parts
            if i.is_dir() or Path(i.filename).is_absolute() or ".." in parts:
                continue
            if parts[: len(prefix)] != prefix or len(parts) <= len(prefix) or parts[len(prefix)] != "yt_dlp_plugins":
                continue
            out = stage.joinpath(*parts[len(prefix):])
            out.parent.mkdir(parents=True, exist_ok=True)
            with z.open(i) as src, open(out, "wb") as f:
                shutil.copyfileobj(src, f)
    if not plugin_files(stage):
        shutil.rmtree(stage, ignore_errors=True)
        raise ValueError("the archive has a yt_dlp_plugins folder but no extractor/ or postprocessor/ plugin files")
    (stage / ".source.json").write_text(json.dumps({"source": source, "added": int(time.time())}))
    dest = PLUGINS_DIR / name
    shutil.rmtree(dest, ignore_errors=True)
    os.replace(stage, dest)
    return plugin_files(dest)


def plugin_zip_candidates(url: str) -> tuple[list[str], str]:
    u = urlparse(url.strip())
    if u.scheme != "https":
        raise ValueError("use an https:// URL")
    if u.path.lower().endswith(".zip"):
        return [url.strip()], Path(u.path).stem
    if u.netloc.lower() in ("github.com", "www.github.com"):
        parts = [x for x in u.path.split("/") if x]
        if len(parts) >= 2:
            user, repo = parts[0], parts[1].removesuffix(".git")
            branches = [parts[3]] if len(parts) >= 4 and parts[2] == "tree" else []
            branches += [b for b in ("main", "master") if b not in branches]
            return [f"https://github.com/{user}/{repo}/archive/refs/heads/{b}.zip" for b in branches], repo
    raise ValueError("give a GitHub repository URL or a direct https link to a .zip")


def plugins_changed() -> None:
    threading.Thread(target=load_extractors, args=(True,), daemon=True).start()


def install_plugin_url(t: Task, url: str) -> None:
    cands, name = plugin_zip_candidates(url)
    last: Exception | None = None
    for c in cands:
        try:
            t.add_log(f"downloading {c}")
            data = http_get(c, 60, 30_000_000)
            break
        except Exception as e:
            last = e
            t.add_log(f"  failed: {e}")
    else:
        raise RuntimeError(f"could not download the plugin ({last})")
    files = extract_plugin_zip(data, name, url)
    t.add_log(f"installed plugin '{name}': " + ", ".join(files))
    plugins_changed()


def install_plugin_pip(t: Task, spec: str) -> None:
    if not PIP_SPEC_RE.fullmatch(spec):
        raise ValueError("not a valid package name (e.g. yt-dlp-get-pot or name==1.2.3)")
    if run_cmd(t, pip_cmd(VENV_BIN / "python", ["-U", spec])) != 0:
        raise RuntimeError(f"pip could not install {spec}")
    t.add_log(f"installed {spec}")
    plugins_changed()


def remove_plugin(name: str, kind: str) -> None:
    if kind == "folder":
        if not PLUGIN_NAME_RE.fullmatch(name) or not (PLUGINS_DIR / name).is_dir():
            raise ValueError("no such plugin")
        shutil.rmtree(PLUGINS_DIR / name)
    elif kind == "pip":
        if not PIP_SPEC_RE.fullmatch(name) or name not in [p["name"] for p in pip_plugins()]:
            raise ValueError("no such plugin package")
        py, uv = VENV_BIN / "python", uv_bin()
        cmd = [uv, "pip", "uninstall", "--python", str(py), name] if uv else [str(py), "-m", "pip", "uninstall", "-y", name]
        if subprocess.run(cmd, capture_output=True, env=child_env()).returncode != 0:
            raise RuntimeError("could not uninstall the package")
    else:
        raise ValueError("unknown plugin kind")
    plugins_changed()


# ---- tools overview + "latest" checks -----------------------------------------
LATEST: dict[str, dict] = {}
CHECK = {"running": False, "at": 0}
TOOL_IDS = ("yt-dlp", "gallery-dl", "hls.js")


def check_latest() -> None:
    if CHECK["running"]:
        return
    CHECK["running"] = True
    try:
        pre = S.yt_channel == "pre"
        gh = "https://api.github.com/repos/{}/releases/latest"
        jobs = {
            "yt-dlp": lambda: http_json(gh.format("yt-dlp/yt-dlp-nightly-builds" if pre else "yt-dlp/yt-dlp"))["tag_name"],
            "gallery-dl": lambda: pypi_latest("gallery-dl"),
            "hls.js": lambda: http_json("https://registry.npmjs.org/hls.js/latest")["version"],
        }
        for name, fn in jobs.items():
            try:
                LATEST[name] = {"version": fn(), "error": ""}
            except Exception as e:
                LATEST[name] = {"version": "", "error": str(e)[:160]}
        CHECK["at"] = int(time.time())
    finally:
        CHECK["running"] = False


def tools_view() -> dict:
    cmd = ytdlp_cmd()
    how = "not installed" if not cmd else "release file (yt-dlp -U)" if cmd[-1] == str(BIN_DIR / "yt-dlp") else "pip/system copy"
    inst = {"yt-dlp": ytdlp_version(), "gallery-dl": installed_version("gallery-dl"), "hls.js": hls_installed()}
    info = {"yt-dlp": f"video downloader · {how}" + (" · nightly channel" if S.yt_channel == "pre" else ""),
            "gallery-dl": "image/gallery downloader (also Kemono and Coomer) · updated with uv",
            "hls.js": "browser player library for the transcoded playback path"}
    tools = []
    for tid in TOOL_IDS:
        lt = LATEST.get(tid, {})
        have, want = inst[tid], lt.get("version", "")
        tools.append({"id": tid, "info": info[tid], "installed": have, "latest": want, "error": lt.get("error", ""),
                      "update": bool(want and have and have != want), "missing": not have})
    return {"tools": tools, "checking": CHECK["running"], "checked_at": CHECK["at"], "channel": S.yt_channel,
            "system": {"ffmpeg": bool(shutil.which(FFMPEG)), "web": VERSION}}


def update_tools(t: Task, names: list[str], reinstall: bool = False) -> None:
    failed = []
    for n in names:
        t.message = f"{'Reinstalling' if reinstall else 'Updating'} {n}…"
        t.add_log(f"=== {n} ===")
        try:
            if n == "yt-dlp":
                update_ytdlp(t, reinstall)
            elif n == "gallery-dl":
                update_gdl(t, reinstall)
            elif n == "hls.js":
                update_hls(t)
            LATEST.pop(n, None)
        except Exception as e:
            failed.append(n)
            t.add_log(f"{n}: FAILED: {e}")
    if failed:
        raise RuntimeError("failed: " + ", ".join(failed) + " (see log)")
    t.message = "All selected components are up to date"
    if not t.echo:
        threading.Thread(target=check_latest, daemon=True).start()


# --------------------------------------------------------------------------
# sign-in: first login creates the account, then HTTP basic auth over HTTPS
#   setup  no login exists yet: only the page and the setup call are reachable, everything else answers 403
#   file   login stored in <state>/auth.json (PBKDF2-SHA256); change it in Settings or with `media-dl-web set-password`
#   env    login fixed by MEDIA_DL_WEB_PASSWORD (user: MEDIA_DL_WEB_LOGIN_USER, default media-dl)
#   open   MEDIA_DL_WEB_ALLOW_OPEN=1 and no login: no authentication at all (unsafe)
# --------------------------------------------------------------------------
AUTH_ITER = 200_000
USER_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{2,31}")
MIN_PASSWORD = 8
_AUTH: dict = {"mtime": None, "data": None}      # auth.json cache; re-read when the file changes (so the CLI needs no restart)
_AUTH_OK: dict[str, float] = {}                   # sha256(Authorization header) -> expiry: skips PBKDF2 on repeat requests
_AUTH_FAILS: dict[str, list[float]] = {}          # client ip -> times of recent failures
AUTH_LOCK = threading.Lock()
SETUP_LOCK = threading.Lock()
MAX_FAILS, FAIL_WINDOW, OK_TTL = 8, 300, 12 * 3600


def auth_file() -> Path:
    return S.state / "auth.json"


def load_auth() -> dict | None:
    f = auth_file()
    try:
        st = f.stat()
    except OSError:
        _AUTH.update(mtime=None, data=None)
        return None
    if _AUTH["mtime"] != st.st_mtime_ns:
        try:
            d = json.loads(f.read_text())
            good = isinstance(d, dict) and all(k in d for k in ("user", "salt", "hash", "iter"))
        except Exception:
            d, good = None, False
        _AUTH.update(mtime=st.st_mtime_ns, data=d if good else None)
        _AUTH_OK.clear()
    return _AUTH["data"]


def hash_password(password: str, salt: bytes, iterations: int) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iterations).hex()


def validate_credentials(user: str, password: str) -> None:
    if not USER_RE.fullmatch(user or ""):
        raise ValueError("user name: 3 to 32 characters, letters, digits, . _ - (start with a letter or digit)")
    if len(password or "") < MIN_PASSWORD:
        raise ValueError(f"the password needs at least {MIN_PASSWORD} characters")
    if len(password) > 200 or "\x00" in password or "\n" in password or "\r" in password:
        raise ValueError("the password contains characters that cannot be used")
    if password.lower() == user.lower():
        raise ValueError("the password must not be the same as the user name")


def save_auth(user: str, password: str) -> None:
    validate_credentials(user, password)
    salt = os.urandom(16)
    data = {"user": user, "algo": "pbkdf2_sha256", "iter": AUTH_ITER, "salt": salt.hex(),
            "hash": hash_password(password, salt, AUTH_ITER), "changed": int(time.time())}
    S.state.mkdir(parents=True, exist_ok=True)
    tmp = auth_file().with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2))
    os.chmod(tmp, 0o600)
    if os.geteuid() == 0:                            # `sudo media-dl-web set-password`: the service user must still be able to read it
        st = S.state.stat()
        os.chown(tmp, st.st_uid, st.st_gid)
    os.replace(tmp, auth_file())
    _AUTH.update(mtime=None, data=None)
    _AUTH_OK.clear()


def verify_password(user: str, password: str) -> bool:
    """Check a user name + password against the configured login (constant time)."""
    if S.password:
        return hmac.compare_digest(user.encode(), S.user.encode()) & hmac.compare_digest(password.encode(), S.password.encode())
    a = load_auth()
    if not a:
        return False
    try:
        mine = hash_password(password, bytes.fromhex(a["salt"]), int(a["iter"]))
    except Exception:
        return False
    return hmac.compare_digest(user.encode(), a["user"].encode()) & hmac.compare_digest(mine.encode(), a["hash"].encode())


def auth_mode() -> str:
    if S.password:
        return "env"
    if load_auth():
        return "file"
    return "open" if os.environ.get("MEDIA_DL_WEB_ALLOW_OPEN") == "1" else "setup"


def current_user() -> str:
    if S.password:
        return S.user
    a = load_auth()
    return a["user"] if a else ""


def is_loopback_ip(ip: str) -> bool:
    ip = ip[7:] if ip.startswith("::ffff:") else ip
    return ip in ("::1", "localhost") or ip.startswith("127.")


def lan_urls() -> list[str]:
    host = socket.gethostname() or "localhost"
    names = ["127.0.0.1"] + lan_ips() + ([host] if host != "localhost" else [])
    return [f"{S.scheme}://{n}:{S.port}/" for n in names]


def cli_set_password(argv: list[str]) -> int:
    """media-dl-web set-password [--user NAME] [--password-stdin]   (run with sudo for the service)"""
    import getpass
    ap = argparse.ArgumentParser(prog="media-dl-web set-password")
    ap.add_argument("--user", help="user name (default: the current one, or 'admin')")
    ap.add_argument("--password-stdin", action="store_true", help="read the password from standard input (for scripts)")
    a = ap.parse_args(argv)
    old = load_auth()
    user = a.user or (old or {}).get("user") or "admin"
    if not a.user and sys.stdin.isatty():
        user = input(f"User name [{user}]: ").strip() or user
    if a.password_stdin:
        pw = sys.stdin.readline().rstrip("\n")
    else:
        pw = getpass.getpass("New password: ")
        if pw != getpass.getpass("Repeat password: "):
            print("the two passwords differ")
            return 1
    try:
        save_auth(user, pw)
    except ValueError as e:
        print(f"not saved: {e}")
        return 1
    except PermissionError:
        print(f"not saved: no permission to write {auth_file()}  (run it with sudo)")
        return 1
    print(f"saved: user '{user}' ({auth_file()}). Takes effect immediately; the browser will ask for the new details.")
    return 0


def cli_reset_auth() -> int:
    """media-dl-web reset-auth: forget the login, so the next visit shows the first-run page again."""
    try:
        auth_file().unlink()
        print("login removed: the next visit to the page asks you to create a new one")
    except FileNotFoundError:
        print("there was no stored login")
    except PermissionError:
        print(f"no permission to remove {auth_file()}  (run it with sudo)")
        return 1
    _AUTH.update(mtime=None, data=None)
    return 0


def cli_auth_status() -> int:
    print(f"sign-in mode: {auth_mode()}   user: {current_user() or '-'}   state: {S.state}")
    return 0


# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = f"media-dl-web/{VERSION}"
    protocol_version = "HTTP/1.1"
    timeout = 120                                   # also bounds the TLS handshake of a stalled client

    def handle(self):
        try:
            super().handle()
        except (ssl.SSLError, ConnectionError, TimeoutError, OSError):
            pass                                    # http:// request to the https port, resets, stalls

    def log_message(self, fmt, *args):      # keep the journal quiet; errors are logged below
        pass

    # ---- helpers
    def _host_ok(self) -> bool:
        if S.host not in ("127.0.0.1", "localhost", "::1"):
            return True                       # listening on the network: a password is mandatory instead
        h = (self.headers.get("Host") or "").strip().lower()
        name = h[1:h.index("]")] if h.startswith("[") and "]" in h else h.rsplit(":", 1)[0]
        extra = {x.strip().lower() for x in os.environ.get("MEDIA_DL_WEB_ALLOWED_HOSTS", "").split(",") if x.strip()}
        return name in {"localhost", "127.0.0.1", "::1"} | extra

    def _client_ip(self) -> str:
        ip = self.client_address[0]
        return ip[7:] if ip.startswith("::ffff:") else ip

    def _login_state(self) -> str:
        """'ok', 'denied' or 'limited' (too many recent failures from this address)."""
        h = self.headers.get("Authorization", "")
        ip, now = self._client_ip(), time.time()
        key = hashlib.sha256(h.encode()).hexdigest()
        with AUTH_LOCK:
            fails = [t for t in _AUTH_FAILS.get(ip, []) if now - t < FAIL_WINDOW]
            _AUTH_FAILS[ip] = fails
            if len(fails) >= MAX_FAILS:
                return "limited"
            if _AUTH_OK.get(key, 0) > now:
                return "ok"
        if not h.startswith("Basic "):
            return "denied"                           # the first request of a browser has no header yet: not a failure
        try:
            raw = base64.b64decode(h[6:])
            try:
                text = raw.decode("utf-8")
            except UnicodeDecodeError:
                text = raw.decode("latin-1")
            user, _, pw = text.partition(":")
            ok = verify_password(user, pw)
        except Exception:
            ok = False
        with AUTH_LOCK:
            if ok:
                if len(_AUTH_OK) > 500:
                    _AUTH_OK.clear()
                _AUTH_OK[key] = now + OK_TTL
                _AUTH_FAILS.pop(ip, None)
                return "ok"
            _AUTH_FAILS.setdefault(ip, []).append(now)
        time.sleep(0.3)                               # slow down guessing a little
        return "denied"

    def _send(self, code: int, body: bytes = b"", ctype: str = "text/plain; charset=utf-8", extra: dict | None = None,
              head: bool = False) -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if not head and body:
            self.wfile.write(body)

    def _json(self, obj, code: int = 200, head: bool = False) -> None:
        self._send(code, json.dumps(obj).encode(), "application/json", {"Cache-Control": "no-store"}, head)

    def _err(self, code: int, msg: str) -> None:
        self._json({"error": msg}, code)

    def _file(self, path: Path, head: bool = False, download: bool = False, ctype: str | None = None,
              cache: str = "no-cache", extra: dict | None = None) -> None:
        size = path.stat().st_size
        ctype = ctype or mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        start, end, code = 0, size - 1, 200
        rng = self.headers.get("Range")
        if rng:
            m = re.match(r"bytes=(\d*)-(\d*)$", rng.strip())
            if not m or (not m.group(1) and not m.group(2)):
                return self._send(416, extra={"Content-Range": f"bytes */{size}"}, head=head)
            if m.group(1):
                start = int(m.group(1))
                end = int(m.group(2)) if m.group(2) else size - 1
            else:
                start = max(0, size - int(m.group(2)))
            end = min(end, size - 1)
            if start > end or start >= size:
                return self._send(416, extra={"Content-Range": f"bytes */{size}"}, head=head)
            code = 206
        length = end - start + 1
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", cache)
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        if code == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        if download:
            from urllib.parse import quote
            self.send_header("Content-Disposition", f"attachment; filename*=UTF-8''{quote(path.name)}")
        self.end_headers()
        if head:
            return
        try:
            with open(path, "rb") as f:
                f.seek(start)
                left = length
                while left > 0:
                    chunk = f.read(min(262144, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _body(self, limit: int = 1_000_000) -> dict:
        n = int(self.headers.get("Content-Length") or 0)
        if n > limit:
            raise ValueError("body too large")
        raw = self.rfile.read(n) if n else b"{}"
        return json.loads(raw or b"{}")

    # ---- verbs
    def do_HEAD(self):
        self._route(head=True)

    def do_GET(self):
        self._route()

    def do_POST(self):
        self._route(post=True)

    def _route(self, head: bool = False, post: bool = False):
        try:
            if not self._host_ok():
                return self._err(403, "Host header not allowed (DNS-rebinding protection). "
                                      "Add the name to MEDIA_DL_WEB_ALLOWED_HOSTS or use localhost.")
            u = urlparse(self.path)
            path, q = u.path, parse_qs(u.query)
            mode = auth_mode()
            if mode == "setup":
                # nothing works until the login exists: only the page, its assets, the status calls and the setup call
                open_get = path in ("/", "/index.html", "/api/config", "/api/auth/status") or path.startswith("/static/")
                if not ((not post and open_get) or (post and path == "/api/auth/setup")):
                    return self._json({"error": "first-run setup required: open the page and create the login", "setup": True}, 403)
            elif mode in ("env", "file"):
                st = self._login_state()
                if st == "limited":
                    return self._send(429, b"too many failed sign-ins; try again in a few minutes",
                                      extra={"Retry-After": str(FAIL_WINDOW)}, head=head)
                if st != "ok":
                    return self._send(401, b"authentication required", extra={
                        "WWW-Authenticate": 'Basic realm="Media-DL Web", charset="UTF-8"'}, head=head)
            if post:
                if "application/json" not in (self.headers.get("Content-Type") or ""):
                    return self._err(415, "JSON required")      # blocks cross-site form posts
                return self._post(path)
            return self._get(path, q, head)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            try:
                self._err(500, f"{type(e).__name__}: {e}")
            except Exception:
                pass

    # ---- GET
    def _get(self, path: str, q: dict, head: bool):
        if path in ("/", "/index.html"):
            return self._file(STATIC_DIR / "index.html", head, ctype="text/html; charset=utf-8", extra={
                "Content-Security-Policy": "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; "
                                           "style-src 'self' 'unsafe-inline'; script-src 'self'; "
                                           "worker-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'",
                "Referrer-Policy": "no-referrer"})
        if path.startswith("/static/"):
            p = (STATIC_DIR / path[8:]).resolve()
            if STATIC_DIR.resolve() in p.parents and p.is_file():
                return self._file(p, head, cache="max-age=300")
            return self._err(404, "not found")
        if path == "/vendor/hls.min.js":
            p = VENDOR_DIR / "hls.min.js"
            if p.is_file():
                return self._file(p, head, ctype="application/javascript", cache="max-age=86400")
            return self._err(404, "hls.js not installed")
        if path == "/api/auth/status":
            mode = auth_mode()
            return self._json({"mode": mode, "user": current_user() if mode != "setup" else "",
                               "setup_local_only": os.environ.get("MEDIA_DL_WEB_SETUP_LOCAL_ONLY") == "1",
                               "setup_allowed": os.environ.get("MEDIA_DL_WEB_SETUP_LOCAL_ONLY") != "1" or is_loopback_ip(self._client_ip())})
        if path == "/api/config" and auth_mode() == "setup":       # first run: reveal nothing but what the setup page needs
            return self._json({"version": VERSION, "auth_mode": "setup", "https": S.scheme == "https",
                               "setup_local_only": os.environ.get("MEDIA_DL_WEB_SETUP_LOCAL_ONLY") == "1",
                               "setup_allowed": os.environ.get("MEDIA_DL_WEB_SETUP_LOCAL_ONLY") != "1" or is_loopback_ip(self._client_ip())})
        if path == "/api/config":
            return self._json({"version": VERSION, "auth_mode": auth_mode(), "auth_user": current_user(), "outdir": str(S.outdir), "has_hls_local": (VENDOR_DIR / "hls.min.js").is_file(),
                               "yt_dlp": ytdlp_cmd() is not None,
                               "gallery_dl": Path(GDL).exists() or bool(shutil.which(GDL)),
                               "ffmpeg": bool(shutil.which(FFMPEG)), "auth": auth_mode() in ("env", "file"),
                               "extra_args": os.environ.get("MEDIA_DL_WEB_NO_EXTRA_ARGS") != "1",
                               "plugins": plugins_enabled(), "https": S.scheme == "https",
                               "proxy": bool(S.proxy and S.proxy_downloads),
                               "wallpaper": S.wallpaper, "wallpaper_v": hashlib.sha1(S.wallpaper_b64.encode()).hexdigest()[:10] if S.wallpaper else "",
                               "preset": S.preset, "cache_mb": S.cache_mb, "yt_channel": S.yt_channel,
                               "host": S.host, "port": S.port})
        if path == "/api/wallpaper":
            if not (S.wallpaper and S.wallpaper_b64):
                return self._err(404, "no wallpaper")
            if "b" not in _WP:
                _WP["b"], _WP["t"] = decode_wallpaper(S.wallpaper_b64)
            return self._send(200, _WP["b"], _WP["t"], {"Cache-Control": "max-age=86400"}, head)
        if path == "/api/cert.pem":
            c = tls_files()[0]
            if S.scheme != "https" or not c.is_file():
                return self._err(404, "no certificate (not using https, or none created yet)")
            return self._file(c, head, download=True, ctype="application/x-pem-file")
        if path == "/api/plugins":
            return self._json(plugins_list())
        if path == "/api/extractors":
            return self._json(EXT)
        if path == "/api/files":
            return self._json({"files": list_library()})
        if path == "/api/tools":
            return self._json(tools_view())
        if path == "/api/settings":
            return self._json({"outdir": str(S.outdir), "preset": S.preset, "presets": list(PRESETS),
                               "cache_mb": S.cache_mb, "yt_channel": S.yt_channel, "kemono": S.kemono,
                               "wallpaper": S.wallpaper, "wallpaper_set": bool(S.wallpaper_b64),
                               "proxy": redact(S.proxy), "proxy_downloads": S.proxy_downloads,
                               "proxy_updates": S.proxy_updates, "proxy_locked": bool(os.environ.get("MEDIA_DL_WEB_PROXY")),
                               "host": S.host, "port": S.port, "auth": auth_mode() in ("env", "file"), "auth_mode": auth_mode(),
                               "auth_user": current_user(), "version": VERSION,
                               "https": S.scheme == "https",
                               "paths": {"venv": str(VENV), "app": str(APP), "state": str(S.state),
                                         "cache": str(S.cache), "temp": str(S.tmp), "plugins": str(PLUGINS_DIR),
                                         "yt-dlp": str(BIN_DIR / "yt-dlp")}})
        m = re.fullmatch(r"/api/tasks/([0-9a-f]+)", path)
        if m:
            t = TASKS.get(m.group(1))
            if not t:
                return self._err(404, "no such task")
            return self._json(t.view(int((q.get("from") or ["0"])[0])))
        if path == "/api/jobs":
            with LOCK:
                return self._json({"jobs": [{"id": j.id, "url": j.url, "state": j.state, "preview": j.preview}
                                            for j in sorted(JOBS.values(), key=lambda x: -x.created)]})
        m = re.fullmatch(r"/api/jobs/([0-9a-f]+)", path)
        if m:
            j = JOBS.get(m.group(1))
            if not j:
                return self._err(404, "no such job")
            return self._json(j.view(int((q.get("from") or ["0"])[0])))
        m = re.fullmatch(r"/api/jobs/([0-9a-f]+)/img/(\d+)", path)
        if m:
            return self._job_image(m.group(1), int(m.group(2)), head)
        m = re.fullmatch(r"/api/play/([A-Za-z0-9_\-]+)", path)
        if m:
            p = resolve_token(m.group(1))
            if not p:
                return self._err(404, "file not found")
            tok = m.group(1)
            if kind_of(p) == "image":
                return self._json({"mode": "image", "direct": f"/media/{tok}"})
            info = probe(p)
            return self._json({"mode": "direct" if direct_ok(info, p.suffix) else "hls", "info": info,
                               "direct": f"/media/{tok}", "has_video": info["has_video"],
                               "hls": f"/hls/{tok}/{{maxh}}/index.m3u8"})
        m = re.fullmatch(r"/media/([A-Za-z0-9_\-]+)", path)
        if m:
            p = resolve_token(m.group(1))
            if not p:
                return self._err(404, "file not found")
            return self._file(p, head, download=bool(q.get("dl")))
        m = re.fullmatch(r"/thumb/([A-Za-z0-9_\-]+)", path)
        if m:
            p = resolve_token(m.group(1))
            if not p:
                return self._err(404, "file not found")
            try:
                return self._file(thumb(p), head, ctype="image/jpeg", cache="max-age=86400")
            except Exception:
                return self._err(404, "no thumbnail")
        m = re.fullmatch(r"/hls/([A-Za-z0-9_\-]+)/(\d+)/index\.m3u8", path)
        if m:
            p = resolve_token(m.group(1))
            if not p:
                return self._err(404, "file not found")
            return self._send(200, playlist(p).encode(), "application/vnd.apple.mpegurl",
                              {"Cache-Control": "no-cache"}, head)
        m = re.fullmatch(r"/hls/([A-Za-z0-9_\-]+)/(\d+)/seg(\d+)\.ts", path)
        if m:
            p = resolve_token(m.group(1))
            if not p:
                return self._err(404, "file not found")
            maxh, n = max(144, min(int(m.group(2)), 2160)), int(m.group(3))
            info = probe(p)
            total = max(1, int(-(-info["duration"] // SEG)))
            if n >= total:
                return self._err(404, "no such segment")
            seg = make_segment(p, maxh, n)
            prefetch(p, maxh, n, total)
            return self._file(seg, head, ctype="video/mp2t", cache="max-age=3600")
        return self._err(404, "not found")

    def _job_image(self, jid: str, idx: int, head: bool):
        j = JOBS.get(jid)
        if not j or idx >= len(j.urls):
            return self._err(404, "no such image")
        d = preview_dir(jid) / "_img"
        d.mkdir(parents=True, exist_ok=True)
        u = j.urls[idx]
        ext = Path(urlparse(u).path).suffix.lower()
        if ext not in IMG_EXT and ext not in VID_EXT:
            ext = ".jpg"
        dest = d / f"{idx:02d}{ext}"
        if not dest.exists():
            req = urllib.request.Request(u, headers={"User-Agent": UA, "Referer": j.url})
            with opener_for(j.proxy).open(req, timeout=30) as r, open(dest, "wb") as f:
                shutil.copyfileobj(r, f)
        if dest.suffix.lower() in IMG_EXT:
            return self._file(dest, head)
        try:                                            # a video among the images: send a still frame
            return self._file(thumb(dest), head, ctype="image/jpeg")
        except Exception:
            return self._err(404, "no preview")

    # ---- POST
    BIG_BODY = ("/api/settings", "/api/plugins/upload")        # wallpaper / plugin zip arrive as base64 in JSON

    def _post(self, path: str):
        body = self._body(16_000_000 if path in self.BIG_BODY else 1_000_000)
        if path == "/api/jobs":
            url = (body.get("url") or "").strip()
            if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", url) and not url.startswith("ytsearch"):
                return self._err(400, "enter a full URL (https://…)")
            req = {k: body.get(k) for k in ("url", "mode", "tie", "format", "noplaylist", "restrict", "selected",
                                            "generic", "cookies", "ytx", "gdx", "preview", "kemono", "proxy")} | {"url": url}
            try:
                job_proxy(req)
            except ValueError as e:
                return self._err(400, str(e))
            if req.get("mode") not in ("auto", "video", "image", "direct"):
                req["mode"] = "auto"
            if req.get("kemono"):
                req["mode"], req["preview"] = "image", False
            j = new_job(req)
            return self._json({"id": j.id})
        m = re.fullmatch(r"/api/jobs/([0-9a-f]+)/cancel", path)
        if m:
            j = JOBS.get(m.group(1))
            if not j:
                return self._err(404, "no such job")
            j.cancelled = True
            if j.proc and j.proc.poll() is None:
                try:
                    os.killpg(j.proc.pid, signal.SIGTERM)
                except OSError:
                    j.proc.terminate()
            return self._json({"ok": True})
        m = re.fullmatch(r"/api/jobs/([0-9a-f]+)/save", path)
        if m:
            j = JOBS.get(m.group(1))
            if not j or not j.preview:
                return self._err(404, "no such preview")
            try:
                saved = save_preview(j)
            except OSError as e:
                return self._err(500, f"could not copy into the library: {e}")
            return self._json({"saved": saved, "count": len(saved)})
        m = re.fullmatch(r"/api/jobs/([0-9a-f]+)/discard", path)
        if m:                                        # idempotent: also used by sendBeacon when the page closes
            discard_preview(m.group(1))
            return self._json({"ok": True})
        if path == "/api/match":
            url = (body.get("url") or "").strip()
            try:
                return self._json({"names": ytdlp_matches(url)})
            except Exception as e:
                return self._err(500, f"could not match: {e}")
        if path == "/api/extractors/refresh":
            threading.Thread(target=load_extractors, args=(True,), daemon=True).start()
            return self._json({"ok": True})
        if path == "/api/outdir":
            try:
                return self._json({"outdir": str(set_outdir(body.get("path")))})
            except Exception as e:
                return self._err(400, f"not usable: {e}")
        if path == "/api/tools/check":
            threading.Thread(target=check_latest, daemon=True).start()
            return self._json({"ok": True})
        if path == "/api/tools/update":
            names = [n for n in (body.get("names") or []) if n in TOOL_IDS]
            if not names:
                return self._err(400, "nothing selected")
            re_ = bool(body.get("reinstall"))
            t = start_task(("Reinstall " if re_ else "Update ") + ", ".join(names), update_tools, names, re_)
            return self._json({"task": t.id})
        if path.startswith("/api/plugins/"):
            if not plugins_enabled():
                return self._err(403, "plugins are disabled by the administrator (MEDIA_DL_WEB_NO_EXTRA_ARGS=1)")
            try:
                if path == "/api/plugins/add":
                    if body.get("url"):
                        t = start_task("Add plugin", install_plugin_url, str(body["url"]))
                    elif body.get("pip"):
                        t = start_task("Add plugin package", install_plugin_pip, str(body["pip"]).strip())
                    else:
                        return self._err(400, "give a GitHub/zip URL or a pip package name")
                    return self._json({"task": t.id})
                if path == "/api/plugins/upload":
                    name = re.sub(r"\.zip$", "", str(body.get("name") or "plugin"), flags=re.I)
                    name = re.sub(r"[^A-Za-z0-9._-]+", "-", name).strip("-.")[:64] or "plugin"
                    raw = base64.b64decode(str(body.get("data") or ""), validate=True)
                    files = extract_plugin_zip(raw, name, "uploaded zip")
                    plugins_changed()
                    return self._json({"name": name, "files": files})
                if path == "/api/plugins/remove":
                    remove_plugin(str(body.get("name") or ""), str(body.get("kind") or ""))
                    return self._json({"ok": True})
            except (ValueError, zipfile.BadZipFile, RuntimeError) as e:
                return self._err(400, str(e))
        if path == "/api/settings":
            try:
                if "outdir" in body and str(body["outdir"]) != str(S.outdir):
                    set_outdir(body["outdir"])
                if body.get("preset") in PRESETS:
                    S.preset = body["preset"]
                if "cache_mb" in body:
                    mb = int(body["cache_mb"])
                    if not 128 <= mb <= 1048576:
                        raise ValueError("cache size must be between 128 MB and 1 TB")
                    S.cache_mb = mb
                if body.get("yt_channel") in ("stable", "pre"):
                    S.yt_channel = body["yt_channel"]
                if isinstance(body.get("kemono"), dict):
                    S.kemono = clean_kemono({**S.kemono, **body["kemono"]})
                if "proxy" in body:
                    new = str(body["proxy"] or "").strip()
                    if new and new == redact(S.proxy) and S.proxy:
                        pass                                   # the masked value came back unchanged: keep the real one
                    else:
                        if os.environ.get("MEDIA_DL_WEB_PROXY") and new != S.proxy:
                            raise ValueError("the proxy is fixed by MEDIA_DL_WEB_PROXY in /etc/default/media-dl-web")
                        S.proxy = clean_proxy(new)
                if "proxy_downloads" in body:
                    S.proxy_downloads = bool(body["proxy_downloads"])
                if "proxy_updates" in body:
                    S.proxy_updates = bool(body["proxy_updates"])
                if "wallpaper_image" in body:
                    img = body["wallpaper_image"]
                    if img:
                        decode_wallpaper(img)
                        S.wallpaper_b64 = str(img).split(",", 1)[-1].strip()
                    else:
                        S.wallpaper_b64 = ""
                if "wallpaper" in body:
                    S.wallpaper = bool(body["wallpaper"])
                S.wallpaper = S.wallpaper and bool(S.wallpaper_b64)
                _WP.clear()
                save_persisted()
                return self._json({"ok": True})
            except Exception as e:
                return self._err(400, str(e))
        if path == "/api/auth/setup":
            if os.environ.get("MEDIA_DL_WEB_SETUP_LOCAL_ONLY") == "1" and not is_loopback_ip(self._client_ip()):
                return self._err(403, "the first-run setup is restricted to this machine (MEDIA_DL_WEB_SETUP_LOCAL_ONLY=1). "
                                      "Open the page on the server itself, or run: sudo media-dl-web set-password")
            with SETUP_LOCK:
                if auth_mode() not in ("setup", "open"):          # "open" = explicit no-login mode: creating a login switches auth on
                    return self._err(409, "a login already exists")
                try:
                    user = str(body.get("user") or "").strip()
                    save_auth(user, str(body.get("password") or ""))
                except ValueError as e:
                    return self._err(400, str(e))
                except OSError as e:
                    return self._err(500, f"could not store the login: {e}")
            return self._json({"ok": True, "user": user})
        if path == "/api/auth/change":
            if S.password:
                return self._err(400, "the login is fixed by MEDIA_DL_WEB_PASSWORD in /etc/media-dl-web/password.env; change it there")
            if auth_mode() != "file":
                return self._err(400, "no stored login to change")
            ip, now = self._client_ip(), time.time()
            with AUTH_LOCK:
                fails = [t for t in _AUTH_FAILS.get(ip, []) if now - t < FAIL_WINDOW]
                _AUTH_FAILS[ip] = fails
                if len(fails) >= MAX_FAILS:
                    return self._err(429, "too many failed attempts; try again in a few minutes")
            if not verify_password(current_user(), str(body.get("current") or "")):
                with AUTH_LOCK:
                    _AUTH_FAILS.setdefault(ip, []).append(now)
                time.sleep(0.3)
                return self._err(403, "the current password is not correct")
            try:
                save_auth(str(body.get("user") or current_user()).strip(), str(body.get("password") or ""))
            except ValueError as e:
                return self._err(400, str(e))
            return self._json({"ok": True, "user": current_user()})
        if path == "/api/proxy/test":
            new = str(body.get("proxy") or "").strip()
            try:
                proxy = S.proxy if (not new or (S.proxy and new == redact(S.proxy))) else clean_proxy(new)
            except ValueError as e:
                return self._err(400, str(e))
            url = os.environ.get("MEDIA_DL_WEB_PROXY_TEST_URL", "https://www.cloudflare.com/cdn-cgi/trace")
            t0 = time.time()
            try:
                with opener_for(proxy).open(urllib.request.Request(url, headers={"User-Agent": UA}), timeout=12) as r:
                    text = r.read(4096).decode(errors="replace")
                info = dict(l.split("=", 1) for l in text.splitlines() if "=" in l)
                return self._json({"ok": True, "via": redact(proxy) or "no proxy", "ms": int((time.time() - t0) * 1000),
                                   "ip": info.get("ip", ""), "country": info.get("loc", "")})
            except Exception as e:
                return self._json({"ok": False, "via": redact(proxy) or "no proxy", "error": redact(str(e))[:200]})
        if path == "/api/files/delete":
            tok = str(body.get("token") or "")
            p = resolve_token(tok)
            try:
                root = base64.urlsafe_b64decode(tok + "=" * (-len(tok) % 4)).decode().split("\0", 1)[0]
            except Exception:
                root = ""
            if not p or root != "lib":
                return self._err(404, "file not found")
            p.unlink()
            d, base = p.parent, S.outdir.resolve()
            while d != base and base in d.parents:        # tidy up emptied folders
                try:
                    d.rmdir()
                except OSError:
                    break
                d = d.parent
            return self._json({"ok": True})
        return self._err(404, "not found")


# --------------------------------------------------------------------------
# HTTPS: self-signed certificate created on first start (or bring your own)
# --------------------------------------------------------------------------
_WP: dict = {}


def tls_files() -> tuple[Path, Path]:
    c, k = os.environ.get("MEDIA_DL_WEB_TLS_CERT"), os.environ.get("MEDIA_DL_WEB_TLS_KEY")
    if c and k:
        return Path(c), Path(k)
    return S.state / "tls" / "cert.pem", S.state / "tls" / "key.pem"


def lan_ips() -> list[str]:
    ips: list[str] = []
    try:
        ips += socket.gethostbyname_ex(socket.gethostname())[2]
    except OSError:
        pass
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))
            ips.append(s.getsockname()[0])
    except OSError:
        pass
    return sorted({i for i in ips if i and not i.startswith("127.")})


def cert_ok(cert: Path) -> bool:
    """Exists and is valid for at least another 30 days."""
    if not cert.is_file():
        return False
    if shutil.which("openssl"):
        return subprocess.run(["openssl", "x509", "-checkend", str(30 * 86400), "-noout", "-in", str(cert)],
                              capture_output=True).returncode == 0
    try:
        from cryptography import x509
        c = x509.load_pem_x509_certificate(cert.read_bytes())
        return (c.not_valid_after_utc.timestamp() - time.time()) > 30 * 86400
    except Exception:
        return True


def make_cert(cert: Path, key: Path) -> None:
    host = socket.gethostname() or "localhost"
    dns = ["localhost", host] + ([host + ".local"] if "." not in host else [])
    ips = ["127.0.0.1", "::1"] + lan_ips()
    import ipaddress as _ipa
    for n in [x.strip() for x in os.environ.get("MEDIA_DL_WEB_TLS_NAMES", "").split(",") if x.strip()]:   # extra names/IPs for the certificate
        try:
            _ipa.ip_address(n)
            ips.append(n)
        except ValueError:
            dns.append(n)
    cert.parent.mkdir(parents=True, exist_ok=True)
    san = ",".join([f"DNS:{d}" for d in dns] + [f"IP:{i}" for i in ips])
    if shutil.which("openssl"):
        r = subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-sha256", "-days", "825", "-nodes",
                            "-keyout", str(key), "-out", str(cert), "-subj", "/CN=media-dl-web",
                            "-addext", f"subjectAltName={san}", "-addext", "extendedKeyUsage=serverAuth"],
                           capture_output=True, text=True)
        if r.returncode == 0:
            os.chmod(key, 0o600)
            return
        err = r.stderr.strip()[-200:]
    else:
        err = "openssl is not installed"
    try:                                                   # fallback: the cryptography package, if present
        import datetime
        import ipaddress
        from cryptography import x509
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID
        k = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "media-dl-web")])
        now = datetime.datetime.now(datetime.timezone.utc)
        alt = [x509.DNSName(d) for d in dns] + [x509.IPAddress(ipaddress.ip_address(i)) for i in ips]
        c = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(k.public_key())
             .serial_number(x509.random_serial_number()).not_valid_before(now - datetime.timedelta(days=1))
             .not_valid_after(now + datetime.timedelta(days=825))
             .add_extension(x509.SubjectAlternativeName(alt), critical=False)
             .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
             .sign(k, hashes.SHA256()))
        key.write_bytes(k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL,
                                        serialization.NoEncryption()))
        os.chmod(key, 0o600)
        cert.write_bytes(c.public_bytes(serialization.Encoding.PEM))
    except ImportError:
        raise RuntimeError(f"could not create a certificate: {err} (install openssl)") from None


def make_ssl_context() -> ssl.SSLContext:
    cert, key = tls_files()
    if os.environ.get("MEDIA_DL_WEB_TLS_CERT"):
        if not (cert.is_file() and key.is_file()):
            raise RuntimeError(f"MEDIA_DL_WEB_TLS_CERT/KEY not found: {cert} {key}")
    elif not (cert_ok(cert) and key.is_file()):
        make_cert(cert, key)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(str(cert), str(key))
    return ctx


def cli_install_ffmpeg() -> int:
    load_persisted()
    if shutil.which(FFMPEG) and shutil.which("ffprobe"):
        print("ffmpeg and ffprobe are already available: " + (shutil.which(FFMPEG) or ""))
        return 0
    t = Task("ffmpeg", echo=True)
    run_task(t, install_ffmpeg)
    return 0 if t.state == "done" else 1


def cli_update(names: list[str]) -> int:
    """media_dl_web.py update [hls.js yt-dlp gallery-dl]  (used by the installer, handy by hand)"""
    load_persisted()
    names = names or ["hls.js"]
    bad = [n for n in names if n not in TOOL_IDS]
    if bad:
        print("unknown component(s): " + ", ".join(bad) + "   (choose from: " + ", ".join(TOOL_IDS) + ")")
        return 2
    t = Task("update", echo=True)
    run_task(t, update_tools, names)
    return 0 if t.state == "done" else 1


def detect_scheme(host: str, port: int) -> str:
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
        with socket.create_connection((host, port), timeout=2) as s, ctx.wrap_socket(s):
            return "https"
    except (OSError, ssl.SSLError):
        return "http"


def cli_open() -> int:
    import webbrowser
    port = int(os.environ.get("MEDIA_DL_WEB_PORT") or Settings.port)
    host = os.environ.get("MEDIA_DL_WEB_HOST") or "127.0.0.1"
    host = "127.0.0.1" if host in ("0.0.0.0", "::", "", "all", "*") else host
    url = f"{detect_scheme(host, port)}://{host}:{port}/"
    print(url)
    webbrowser.open(url)
    return 0


class Server(ThreadingHTTPServer):
    """ThreadingHTTPServer without the slow reverse lookup of the bind address; can bind IPv6 (optionally dual-stack)."""
    daemon_threads = True
    dual = False

    def server_bind(self):
        if self.address_family == socket.AF_INET6:
            self.socket.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0 if self.dual else 1)
        socketserver.TCPServer.server_bind(self)
        self.server_name, self.server_port = self.server_address[0], self.server_address[1]


class Server6(Server):
    address_family = socket.AF_INET6


class ServerDual(Server6):
    dual = True


def make_server(host: str, port: int):
    """('all' | '::' | '' | '*') -> every interface, IPv4 and IPv6 where available; '0.0.0.0' -> IPv4 only."""
    if host in ("all", "*", "", "::"):
        if socket.has_ipv6:
            try:
                return ServerDual(("::", port), Handler), "all interfaces (IPv4 + IPv6)"
            except OSError:
                pass
        return Server(("0.0.0.0", port), Handler), "all interfaces (IPv4)"
    if host == "0.0.0.0":
        return Server((host, port), Handler), "all IPv4 interfaces"
    return (Server6 if ":" in host else Server)((host, port), Handler), host


def main() -> None:
    if len(sys.argv) > 1 and sys.argv[1] == "set-password":
        load_persisted()
        sys.exit(cli_set_password(sys.argv[2:]))
    if len(sys.argv) > 1 and sys.argv[1] == "reset-auth":
        sys.exit(cli_reset_auth())
    if len(sys.argv) > 1 and sys.argv[1] == "auth-status":
        sys.exit(cli_auth_status())
    if len(sys.argv) > 1 and sys.argv[1] == "update":
        sys.exit(cli_update(sys.argv[2:]))
    if len(sys.argv) > 1 and sys.argv[1] == "open":
        sys.exit(cli_open())
    if len(sys.argv) > 1 and sys.argv[1] == "install-ffmpeg":
        sys.exit(cli_install_ffmpeg())
    os.environ["PATH"] = f"{BIN_DIR}:{VENV_BIN}:{os.environ.get('PATH', '')}"
    if len(sys.argv) > 1 and sys.argv[1] == "serve":
        del sys.argv[1]
    ap = argparse.ArgumentParser(description="Browser UI for yt-dlp + gallery-dl",
                                 epilog="other commands:  media_dl_web.py update [hls.js|yt-dlp|gallery-dl ...]   "
                                        "media_dl_web.py install-ffmpeg   media_dl_web.py open   "
                                        "media_dl_web.py set-password   media_dl_web.py reset-auth   media_dl_web.py auth-status")
    ap.add_argument("--host", default=os.environ.get("MEDIA_DL_WEB_HOST", S.host))
    ap.add_argument("--port", type=int, default=int(os.environ.get("MEDIA_DL_WEB_PORT", S.port)))
    ap.add_argument("--password", default=os.environ.get("MEDIA_DL_WEB_PASSWORD", ""),
                    help="fixed login (user: media-dl, or MEDIA_DL_WEB_LOGIN_USER); without it the first visit creates the login")
    ap.add_argument("--out", default="", help="download directory")
    ap.add_argument("--preset", default=os.environ.get("MEDIA_DL_WEB_PRESET", S.preset),
                    help="x264 preset for transcoding (ultrafast..slow)")
    ap.add_argument("--tls", choices=("auto", "1", "0"), default=os.environ.get("MEDIA_DL_WEB_TLS", "auto"),
                    help="HTTPS: auto (default: self-signed certificate, falls back to http if it cannot be made), "
                         "1 (require), 0 (plain http, e.g. behind a TLS reverse proxy)")
    ap.add_argument("--version", action="version", version=VERSION)
    a = ap.parse_args()

    S.host, S.port, S.password, S.preset = a.host, a.port, a.password, a.preset
    S.cache_mb = int(os.environ.get("MEDIA_DL_WEB_CACHE_MB", S.cache_mb))
    load_persisted()
    if a.out:
        S.outdir = Path(a.out).expanduser()

    S.outdir.mkdir(parents=True, exist_ok=True)
    S.cache.mkdir(parents=True, exist_ok=True)
    ensure_tmp()

    threading.Thread(target=load_extractors, daemon=True).start()
    threading.Thread(target=janitor, daemon=True).start()

    srv, where = make_server(S.host, S.port)
    if a.tls != "0":
        try:
            ctx = make_ssl_context()
            # handshake happens in the request thread (not in accept), so one slow client cannot block the others
            srv.socket = ctx.wrap_socket(srv.socket, server_side=True, do_handshake_on_connect=False)
            S.scheme = "https"
        except Exception as e:
            if a.tls == "1":
                sys.exit(f"media-dl-web: HTTPS requested but not possible: {e}")
            print(f"media-dl-web: WARNING: HTTPS is not available ({e}); serving plain http", flush=True)

    def stop(*_):
        for j in list(JOBS.values()):
            j.cancelled = True
            if j.proc and j.proc.poll() is None:
                try:
                    os.killpg(j.proc.pid, signal.SIGTERM)
                except OSError:
                    j.proc.terminate()
        shutil.rmtree(S.tmp / "previews", ignore_errors=True)
        threading.Thread(target=srv.shutdown, daemon=True).start()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    print(f"media-dl-web {VERSION} listening on {S.scheme}://*:{S.port} [{where}]  (downloads: {S.outdir})", flush=True)
    print("  addresses: " + "  ".join(lan_urls()), flush=True)
    mode = auth_mode()
    if mode == "setup":
        print("  FIRST RUN: no login exists yet. Open one of the addresses above and create the user name and password.\n"
              "  Until then nothing else is reachable. (Headless: sudo media-dl-web set-password)", flush=True)
    elif mode == "open":
        print("  WARNING: MEDIA_DL_WEB_ALLOW_OPEN=1 and no login: anyone who can reach this port can use the server.", flush=True)
    else:
        print(f"  sign-in: HTTP basic auth ({'fixed by the environment' if mode == 'env' else 'stored login'}), user '{current_user()}'", flush=True)
    if S.scheme == "https" and not os.environ.get("MEDIA_DL_WEB_TLS_CERT"):
        print(f"  self-signed certificate: {tls_files()[0]} (your browser will ask you to accept it once)", flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
